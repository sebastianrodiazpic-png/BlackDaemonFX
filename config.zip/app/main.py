"""Punto de entrada y orquestador de procesos de BlackDaemonFX.

Expone la CLI del proyecto (`main()`), que selecciona uno de los modos de
ejecucion: recoleccion de datos, analisis historico, backtest, bot demo, papel
en vivo, preflight, prueba de humo, reinicio de base de datos y el daemon
multibot que lanza un worker por perfil de estrategia.

Cada worker es un PROCESO INDEPENDIENTE: un fallo en una estrategia no arrastra
a las demas. Un guardia de instancia unica (`_MultibotInstanceGuard`) impide que
dos daemons operen la misma cuenta a la vez.

Vinculaciones:
    - `brokers.mt5_connector` / `brokers.mt5_data` / `brokers.mt5_execution`:
      acceso al terminal.
    - `strategy.execution.live_trading_engine`: motor de operativa en vivo.
    - `strategy.execution.trade_pipeline`: pipeline de senal a orden.
    - `backtesting.backtest_pipeline`: modo backtest.
    - `database.repository.TradingRepository`: persistencia.
    - `dashboard.realtime_dashboard`: interfaz web.
    - `services.execution_preflight_service` /
      `services.live_demo_smoke_test_service`: verificaciones previas.
    - `config.instruments` / `config.strategy_config`: universo y parametros.
"""

from __future__ import annotations

import argparse
import atexit
import hashlib
import json
import os
import re
from datetime import datetime
from pathlib import Path
import subprocess
import sys
import threading
import time

# Windows puede usar cp1252 en procesos redirigidos. El daemon genera diagnósticos
# Unicode; forzamos UTF-8 para que un print nunca rompa el ciclo operativo.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from daemon_version import DAEMONBLACKFX_VERSION

PROJECT_ROOT = Path(__file__).resolve().parent.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd

from config.instruments import InstrumentManager
from config.strategy_config import TIMEFRAMES
from data.collector import update_historical_csv
from database.repository import TradingRepository
from database.reporting import export_trading_report
from backtesting.backtest_pipeline import run_full_backtest_pipeline
from strategy.execution.trade_pipeline import run_trade_pipeline
from strategy.execution.live_trading_engine import LiveTradingEngine, LiveTradingConfig
from strategy.orb.new_york_orb import discover_orb_symbols, classify_orb_market, is_orb_index_symbol


def _validate_timeframes():
    """Comprueba que `TIMEFRAMES` define structure, confirmation y entry.

    Se ejecuta al arrancar: sin los tres marcos la logica multi-timeframe
    quedaria a medias y es preferible fallar antes de conectar con el broker.

    Raises:
        ValueError: si falta alguna clave.
    """
    required = {"structure", "confirmation", "entry"}
    missing = required.difference(TIMEFRAMES)

    if missing:
        raise ValueError(
            "config.strategy_config.TIMEFRAMES no contiene las claves "
            f"requeridas: {sorted(missing)}"
        )


def _normalize_categories(categories):
    """Normaliza el filtro de categorias de instrumentos de la CLI.

    Acepta lista o cadena separada por comas y devuelve nombres en minusculas.

    Returns:
        list[str] | None: `None` significa "sin filtro", y aguas abajo activa
        el descubrimiento completo (sinteticos + Forex + ORB).
    """
    if categories is None:
        return None

    if isinstance(categories, str):
        categories = categories.split(",")

    normalized = [
        str(category).strip().lower()
        for category in categories
        if str(category).strip()
    ]

    return normalized or None


def _resolve_symbols(provider, symbol=None, categories=None):
    """
    Resuelve los símbolos después de conectar MT5.

    Prioridad:
      1. --symbol explícito.
      2. Instrumentos sintéticos y Forex tradeables descubiertos dinámicamente.
    """
    if symbol:
        return [provider.ensure_symbol(symbol)]

    manager = InstrumentManager(provider.connector)

    normalized_categories = _normalize_categories(categories)
    symbols = manager.get_active_symbols(categories=normalized_categories)

    # Sin filtro explícito de categorías, el daemon incorpora también los
    # cuatro mercados permitidos para ORB New York, si existen en este MT5.
    if normalized_categories is None:
        symbols = sorted(set(symbols).union(discover_orb_symbols(provider)))

    if not symbols:
        raise RuntimeError(
            "No se encontraron instrumentos tradeables "
            "(sintéticos/Forex/ORB) para las categorías solicitadas."
        )

    return symbols


def _require_symbol_for_offline_mode(symbol, mode):
    """Exige `--symbol` en los modos que no abren conexion con MT5.

    Sin terminal no hay descubrimiento de instrumentos, asi que el simbolo debe
    darse a mano.

    Raises:
        ValueError: si no se proporciono simbolo.
    """
    if not symbol:
        raise ValueError(
            f"El modo '{mode}' requiere --symbol porque no abre "
            "una conexión MT5 para descubrir instrumentos."
        )

    return str(symbol)


def collect_once(provider, repo, symbols):
    """Ejecuta un ciclo de recoleccion: snapshot de cuenta e historicos.

    Cada simbolo se procesa en su propio `try`: un instrumento que falle no
    interrumpe la recoleccion del resto.

    Args:
        provider: proveedor de datos MT5.
        repo: repositorio donde se guarda el snapshot de cuenta.
        symbols: instrumentos a actualizar.

    Vinculaciones:
        `data.collector.update_historical_csv` escribe los CSV de velas.
    """
    account = provider.connector.get_account_info()
    repo.save_account_snapshot(account)

    print(
        f"Balance actual: {account['balance']} | "
        f"Equity: {account['equity']}"
    )

    for requested_symbol in symbols:
        try:
            exact = provider.ensure_symbol(requested_symbol)

            path, rows = update_historical_csv(
                provider,
                exact,
                TIMEFRAMES["entry"],
                count=5000,
            )

            print(
                f"{exact}: {rows} velas guardadas en {path}"
            )

        except Exception as error:
            print(
                f"ERROR en {requested_symbol}: {error}"
            )


def run_collector(
    interval_seconds: int = 60,
    once: bool = False,
    symbol=None,
    categories=None,
    market_data_mode: str | None = None,
):
    """Modo `collector`: recolecta historicos en bucle hasta interrumpirlo.

    Args:
        interval_seconds: espera entre ciclos.
        once: si es `True` ejecuta un unico ciclo y termina.
        symbol: instrumento concreto; si se omite, se descubren dinamicamente.
        categories: filtro de categorias.

    La desconexion se hace en `finally` para no dejar la sesion MT5 colgada, y
    `KeyboardInterrupt` se trata como parada limpia.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider

    connector = MT5Connector()
    metadata = MT5DataProvider(connector)
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider
    provider = build_market_data_provider(
        metadata,
        settings=ExternalMarketDataSettings.from_environment(market_data_mode),
    )
    repo = TradingRepository()

    try:
        provider.connect()

        symbols = _resolve_symbols(
            provider,
            symbol=symbol,
            categories=categories,
        )

        print(
            f"Instrumentos seleccionados ({len(symbols)}): "
            f"{symbols}"
        )

        while True:
            print("\n=== CICLO DE RECOLECCIÓN ===")

            collect_once(
                provider,
                repo,
                symbols,
            )

            if once:
                break

            time.sleep(interval_seconds)

    except KeyboardInterrupt:
        print("Automatización detenida por el usuario.")

    finally:
        provider.disconnect()


def analyze_historical(
    symbol: str,
    timeframe: str,
    file_path: str,
):
    """Modo `analyze`: aplica el pipeline SMC a un CSV historico y persiste.

    No conecta con el broker ni opera: solo lee velas de disco, extrae los
    setups y los guarda como senales con `valid=False` para su revision.

    Args:
        symbol: instrumento a etiquetar en los registros.
        timeframe: marco temporal del CSV.
        file_path: ruta del historico.

    Raises:
        FileNotFoundError: si el CSV no existe.

    Vinculaciones:
        `strategy.execution.trade_pipeline.run_trade_pipeline`.
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(
            f"No existe el histórico: {path}"
        )

    df = pd.read_csv(path)
    result = run_trade_pipeline(df)
    repo = TradingRepository()

    saved = 0

    for _, row in result["setups"].iterrows():
        data = {
            "instrument": symbol,
            "timeframe": timeframe,
            "signal_time": row["setup_time"],
            "direction": row["setup_type"].upper(),
            "valid": False,
            "trend_ok": row["trend_ok"],
            "swing_ok": row["swing_ok"],
            "liquidity_ok": row["liquidity_ok"],
            "sweep_ok": row["sweep_ok"],
            "structure_break_ok": row["structure_break_ok"],
            "order_block_ok": row["order_block_ok"],
            "retest_ok": False,
            "premium_discount_ok": row["premium_discount_ok"],
            "confirmation_ok": False,
            "details": row.to_dict(),
        }

        _, created = repo.save_signal_once(data)
        saved += int(created)

    for _, row in result["confirmations"].iterrows():
        data = {
            "instrument": symbol,
            "timeframe": timeframe,
            "signal_time": row["entry_time"],
            "direction": row["direction"],
            "valid": bool(row["valid"]),
            "trend_ok": True,
            "swing_ok": True,
            "liquidity_ok": True,
            "sweep_ok": True,
            "structure_break_ok": True,
            "order_block_ok": True,
            "retest_ok": True,
            "premium_discount_ok": True,
            "confirmation_ok": True,
            "details": row.to_dict(),
        }

        _, created = repo.save_signal_once(data)
        saved += int(created)

    output_dir = Path("storage/analysis")
    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    result["setups"].to_csv(
        output_dir / (
            f"{symbol.replace(' ', '_')}_{timeframe}_setups.csv"
        ),
        index=False,
    )

    result["confirmations"].to_csv(
        output_dir / (
            f"{symbol.replace(' ', '_')}_"
            f"{timeframe}_confirmations.csv"
        ),
        index=False,
    )

    print("\n=== ANÁLISIS SMC COMPLETO ===")

    for key, value in result["summary"].items():
        print(f"{key}: {value}")

    print(
        f"Nuevos registros de señales guardados: {saved}"
    )
    print(
        f"Resultados CSV: {output_dir}"
    )


def run_demo_bot(
    symbols,
    timeframe: str,
    interval_seconds: int,
    once: bool,
    execute: bool,
    risk_percent: float,
    min_rr: float,
    verbose: bool = False,
    debug: bool = False,
    position_monitor_interval: int = 2,
    dashboard: bool = False,
    dashboard_port: int = 8765,
    bot_profile: str = "SYNTHETICS",
    magic: int = 26082026,
    auto_export: bool = True,
    chart_pattern_conflict_min_margin: float = 0.25,
    hard_risk_tolerance: float = 0.035,
    recoverable_quarantine_extra_tolerance: float = 0.015,
    market_data_mode: str | None = None,
):
    """Modo `demo`: ejecuta el bot completo contra una cuenta MT5 DEMO.

    Monta la cadena de produccion (datos, ejecucion, ciclo de vida, reporting,
    monitor de posiciones y dashboard opcional) y entrega el control al
    `LiveTradingEngine`.

    Args:
        symbols: instrumentos a vigilar.
        timeframe: marco de entrada.
        interval_seconds: espera entre ciclos de analisis.
        once: un solo ciclo y salir.
        execute: si es `False`, analiza sin enviar ordenes.
        risk_percent: riesgo por operacion.
        min_rr: RR minimo exigido para aceptar un setup.
        verbose / debug: nivel de detalle por consola.
        position_monitor_interval: cadencia de vigilancia de posiciones.
        dashboard / dashboard_port: interfaz web.
        bot_profile: perfil de estrategia (SYNTHETICS, ORB, ...).
        magic: identificador de las ordenes de este worker; separa las
            posiciones de cada perfil en el terminal.
        auto_export: exporta el Excel al cerrar cada operacion.
        chart_pattern_conflict_min_margin: margen minimo (0-1) exigido para
            que un patron chartista contrario NO bloquee la entrada.
        hard_risk_tolerance: tolerancia (0-1) de exceso de riesgo post-fill
            antes de marcar breach del tope duro.
        recoverable_quarantine_extra_tolerance: tolerancia adicional (0-1)
            hasta la cual un breach se clasifica como recuperable (cuarentena
            temporal) en vez de exigir revision manual.

    Los imports son diferidos para que la CLI arranque sin exigir MetaTrader5
    en modos que no lo necesitan.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider

    from brokers.mt5_execution import MT5ExecutionProvider
    from brokers.mt5_trade_executor import MT5TradeExecutor
    from reporting.trade_reporting_service import (
        TradeReportingConfig,
        TradeReportingService,
    )
    from trade_lifecycle_manager import TradeLifecycleManager
    from reporting.console_reporting_service import (
        ConsoleReportingConfig,
        ConsoleReportingService,
    )

    connector = MT5Connector()
    mt5_metadata_provider = MT5DataProvider(connector)
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider
    market_data_settings = ExternalMarketDataSettings.from_environment(market_data_mode)
    provider = build_market_data_provider(
        mt5_metadata_provider, settings=market_data_settings,
    )
    repo = TradingRepository()

    execution_provider = MT5ExecutionProvider(connector)
    trade_executor = MT5TradeExecutor(
        execution_provider=execution_provider,
        magic=int(magic),
        deviation=20,
    )
    reporting_service = TradeReportingService(
        repository=repo,
        config=TradeReportingConfig(
            source="DEMO",
            output_path=(
                PROJECT_ROOT
                / "storage"
                / "exports"
                / "deriv_demo_trading_report.xlsx"
            ),
            auto_export=bool(auto_export),
            broker="Deriv-Demo",
        ),
    )
    lifecycle_manager = TradeLifecycleManager(
        trade_executor=trade_executor,
        reporting_service=reporting_service,
    )
    console_reporter = ConsoleReportingService(
        ConsoleReportingConfig(verbose=verbose, debug=debug)
    )

    dashboard_service = None
    if dashboard:
        from dashboard.realtime_dashboard import RealtimeDashboardService
        dashboard_service = RealtimeDashboardService(
            repository=repo,
            host="127.0.0.1",
            port=dashboard_port,
        )

    config = LiveTradingConfig(
        source="DEMO",
        entry_timeframe=timeframe,
        risk_percent=risk_percent,
        bot_profile=str(bot_profile).upper(),
        magic=int(magic),
        min_rr=min_rr,
        # v100: reserva de fill y banda inferior calibrada con los cuatro
        # incidentes reales de granularidad observados (exceso máximo 0.74%
        # sobre el hard cap). Reduce falsos cierres sin elevar el límite duro.
        pre_fill_risk_buffer=0.01,
        min_actual_risk_ratio=0.97,
        execution_enabled=execute,
        orb_enabled=(str(bot_profile).upper() == "ORB"),
        forex_event_timeframe="M5",
        first_target_rr=1.0,
        second_target_rr=2.0,
        single_entry_target_rr=2.0,

        runner_extension_enabled=(
            not str(bot_profile).upper().startswith(("FOREX", "VOLATILITY"))
            and str(bot_profile).upper() not in {
                "SYNTHETICS", "BOOM", "CRASH", "STEP", "JUMP", "FLIP", "ORB",
            }
        ),
        runner_extension_first_trigger_rr=2.0,
        runner_extension_first_lock_rr=1.0,
        runner_extension_second_trigger_rr=3.0,
        runner_extension_second_lock_rr=2.0,
        runner_extension_max_target_rr=2.0,

        # Jump sigue operativo, pero necesita confirmaciones reforzadas.
        jump_strict_filter_enabled=True,
        jump_min_confirmation_ratio=0.90,
        jump_min_trade_score=90.0,
        jump_allow_single_fallback=False,
        chart_pattern_conflict_min_margin=chart_pattern_conflict_min_margin,
        hard_risk_tolerance=hard_risk_tolerance,
        recoverable_quarantine_extra_tolerance=recoverable_quarantine_extra_tolerance,
    )

    engine = LiveTradingEngine(
        provider,
        repo,
        config=config,
        executor=execution_provider,
        lifecycle_manager=lifecycle_manager,
        reporting_service=reporting_service,
        console_reporter=console_reporter,
        dashboard_service=dashboard_service,
    )

    try:
        provider.connect()

        symbols = (
            provider.prepare_symbols(symbols)
            if hasattr(provider, "prepare_symbols")
            else [provider.ensure_symbol(symbol) for symbol in symbols]
        )

        if dashboard_service is not None:
            manager = InstrumentManager(provider.connector)
            discovered = manager.get_all_instruments()
            categorized = {}
            forex_set = set(manager.discovery.get_tradeable_forex())
            for discovered_symbol in discovered:
                category = (
                    "forex"
                    if discovered_symbol in forex_set
                    else manager.discovery.classify_symbol(discovered_symbol)
                )
                categorized.setdefault(category, []).append(discovered_symbol)
            # Grupo separado para la estrategia ORB NY. Se descubre directamente
            # desde MT5 porque no forma parte del catálogo de sintéticos.
            for orb_symbol in discover_orb_symbols(provider):
                market = classify_orb_market(orb_symbol) or "ORB"
                categorized.setdefault(f"orb_ny_{market.lower()}", []).append(orb_symbol)
            # v56: no convertir el universo completo del worker en selección global.
            dashboard_service.set_instrument_catalog(categorized, selected_symbols=None)
            dashboard_url = dashboard_service.start(live=True)
            print(f"Dashboard de calidad en tiempo real: {dashboard_url}")
            print(f"Gestión modular de instrumentos: {dashboard_service.instruments_url}")
            print(f"Cuenta activa y estadísticas: {dashboard_service.account_url}")
            print("La selección de instrumentos se aplica desde el siguiente ciclo.")

        account = engine.executor.assert_demo_account()

        print(
            f"MARKET DATA: {market_data_settings.mode.upper()} · "
            f"PROVIDER={market_data_settings.provider.upper()} · MT5=EXECUTION_ONLY"
        )

        # Cuenta activa v24: NO reconstruye ni importa automáticamente el
        # historial completo de la cuenta MT5. La vista de Cuenta activa se
        # alimenta exclusivamente de registros que pasaron por la base
        # operativa local y fueron archivados en trade_journal.
        #
        # La reconciliación de posiciones ABIERTAS se mantiene abajo porque
        # permite recuperar el estado operativo actual del daemon sin poblar
        # el historial completo de la cuenta del broker.

        # Descubrimiento inverso MT5 -> SQLAlchemy. Esto recupera posiciones que
        # siguen abiertas en el terminal pero no existen todavía en la base local
        # (por ejemplo, si la DB fue limpiada, reemplazada o el daemon se cerró
        # antes de persistirlas). Las posiciones con el magic del daemon se
        # adoptan como DEMO; las demás se guardan sólo para visualización.
        try:
            imported = repo.import_open_mt5_positions(
                execution_provider,
                source="DEMO",
                magic=config.magic,
                include_external=True,
            )
            if imported.get("imported_daemon") or imported.get("imported_external"):
                print(
                    "Importación MT5/SQLAlchemy: "
                    f"{imported.get('imported_daemon', 0)} posición(es) del daemon recuperada(s), "
                    f"{imported.get('imported_external', 0)} posición(es) externa(s) guardada(s) sólo para visualización."
                )
        except Exception as exc:
            if debug:
                print(f"Advertencia al importar posiciones abiertas desde MT5: {exc}")

        # Reconciliación al reconectar: SQLite conserva las posiciones OPEN
        # durante una desconexión; al volver MT5 determina cuáles siguen vivas.
        try:
            reconciliation = repo.reconcile_open_trades(execution_provider, source="DEMO")
            if reconciliation.get("closed_synced"):
                print(
                    "Reconciliación MT5/SQLAlchemy: "
                    f"{reconciliation['closed_synced']} operación(es) cerrada(s) sincronizada(s)."
                )
            # También cerramos en SQLite las posiciones externas que se hubieran
            # importado anteriormente para visualización y ya no estén en MT5.
            try:
                repo.reconcile_open_trades(execution_provider, source="MT5_EXTERNAL")
            except Exception:
                pass
            if dashboard_service is not None:
                dashboard_service.mark_live()
        except Exception as exc:
            if debug:
                print(f"Advertencia de reconciliación MT5/SQLAlchemy: {exc}")

        print(f"DAEMONBLACKFX VERSION: {DAEMONBLACKFX_VERSION}")
        print(
            f"BOT ACTIVO: {str(bot_profile).upper()} | MAGIC={int(magic)} | "
            "ESTRATEGIA=SMC/ORB | "
            f"instrumentos={len(symbols)} | auto_export={bool(auto_export)}"
        )
        console_reporter.print_startup(
            account=account,
            execute=execute,
            symbols=symbols,
            interval=interval_seconds,
            risk_percent=risk_percent,
            min_rr=min_rr,
            report_path=reporting_service.exporter.output_path,
        )

        if once:
            outcome = engine.run_once(symbols)
            results = outcome["results"]
            for index, row in enumerate(results, start=1):
                console_reporter.print_result(
                    row,
                    index=index,
                    total=len(results),
                )
            console_reporter.summarize(
                results,
                sync=outcome.get("sync", 0),
                cycle_number=1,
                interval=None,
            )

        else:
            engine.run_daemon(
                symbols,
                interval_seconds=interval_seconds,
                position_monitor_interval=position_monitor_interval,
                console_reporter=console_reporter,
            )

    except KeyboardInterrupt:
        print("Bot detenido por el usuario.")

    finally:
        if dashboard_service is not None:
            dashboard_service.mark_offline("DAEMON DESCONECTADO · ESTADO PERSISTIDO")
            dashboard_service.stop()
        provider.disconnect()


def run_live_paper(
    symbols,
    interval_seconds: int,
    once: bool,
    volume: float,
    market_data_mode: str | None = None,
):
    """Modo `paper`: opera en simulacion con precios reales de MT5.

    Usa `PaperTradeExecutor` en lugar del ejecutor real: lee el mercado en vivo
    pero NO envia ninguna orden al broker. Sirve para validar la estrategia sin
    arriesgar capital.

    Args:
        symbols: instrumentos a analizar.
        interval_seconds: espera entre ciclos.
        once: un solo ciclo y salir.
        volume: tamano nominal de las operaciones simuladas.

    Vinculaciones:
        `strategy.execution.live_paper_trading_engine`,
        `strategy.execution.multi_timeframe`.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider
    from strategy.execution.multi_timeframe import (
        MultiTimeframeAnalyzer,
        MultiTimeframeConfig,
    )
    from strategy.execution.paper_trade_executor import (
        PaperTradeExecutor,
    )
    from strategy.execution.live_paper_trading_engine import (
        LivePaperTradingConfig,
        LivePaperTradingEngine,
    )
    from trade_lifecycle_manager import (
        TradeLifecycleManager,
    )
    from reporting.trade_reporting_service import (
        TradeReportingConfig,
        TradeReportingService,
    )

    connector = MT5Connector()
    metadata = MT5DataProvider(connector)
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider
    provider = build_market_data_provider(
        metadata,
        settings=ExternalMarketDataSettings.from_environment(market_data_mode),
    )

    multi_timeframe_config = MultiTimeframeConfig(
        structure_timeframe=TIMEFRAMES["structure"],
        confirmation_timeframe=TIMEFRAMES["confirmation"],
        entry_timeframe=TIMEFRAMES["entry"],
    )

    analyzer = MultiTimeframeAnalyzer(
        provider,
        config=multi_timeframe_config,
    )

    executor = PaperTradeExecutor()

    repository = TradingRepository()
    reporting_service = TradeReportingService(
        repository=repository,
        config=TradeReportingConfig(
            source="PAPER",
            output_path=(
                PROJECT_ROOT
                / "storage"
                / "exports"
                / "paper_trading_report.xlsx"
            ),
            auto_export=True,
            broker="PAPER",
        ),
    )

    lifecycle_manager = TradeLifecycleManager(
        trade_executor=executor,
        reporting_service=reporting_service,
    )

    engine = LivePaperTradingEngine(
        data_provider=provider,
        analyzer=analyzer,
        lifecycle_manager=lifecycle_manager,
        config=LivePaperTradingConfig(
            volume=volume,
            interval_seconds=interval_seconds,
        ),
    )

    try:
        provider.connect()

        symbols = (
            provider.prepare_symbols(symbols)
            if hasattr(provider, "prepare_symbols")
            else [provider.ensure_symbol(symbol) for symbol in symbols]
        )

        account = connector.get_account_info()
        repository.save_account_snapshot({
            **account,
            "broker": "MT5-DEMO-DATA",
        })

        print(
            "=== LIVE PAPER TRADING - MT5 DEMO DATA ==="
        )
        print(
            f"Cuenta: {account['login']} | "
            f"Servidor: {account['server']}"
        )
        print(
            "IMPORTANTE: no se enviarán órdenes al broker; "
            "las posiciones son PAPER."
        )
        print(
            f"Reporte XLSX: {reporting_service.exporter.output_path}"
        )
        print(
            f"Timeframes: H1={TIMEFRAMES['structure']} | "
            f"M15={TIMEFRAMES['confirmation']} | "
            f"Entrada={TIMEFRAMES['entry']}"
        )
        print(
            f"Instrumentos ({len(symbols)}): {symbols}"
        )

        if once:
            result = engine.run_once(symbols)
            print(result)

        else:
            engine.run_daemon(symbols)

    except KeyboardInterrupt:
        print(
            "Live Paper Trading detenido por el usuario."
        )

    finally:
        provider.disconnect()


def run_demo_preflight(symbols):
    """Modo `preflight`: verifica que el entorno puede operar en DEMO.

    Comprueba terminal conectado, autotrading habilitado, cuenta demo y
    disponibilidad de cada simbolo, e imprime un informe legible. No envia
    ordenes.

    Returns:
        dict con `ready`, `checks` y `failed`.

    Vinculaciones:
        `services.execution_preflight_service.ExecutionPreflightService`.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_execution import MT5ExecutionProvider
    from services.execution_preflight_service import ExecutionPreflightService

    connector = MT5Connector()
    repository = TradingRepository()

    try:
        connector.connect()
        service = ExecutionPreflightService(
            execution_provider=MT5ExecutionProvider(connector),
            repository=repository,
        )
        result = service.run(symbols)

        print("=" * 72)
        print("DERIV DEMO EXECUTION PREFLIGHT")
        print("=" * 72)
        for item in result["checks"]:
            status = "OK" if item["ok"] else "FAIL"
            print(f"[{status}] {item['name']} {item['details']}")
        print("=" * 72)
        if result["ready"]:
            print("STATUS: READY FOR DEMO EXECUTION")
        else:
            print("STATUS: NOT READY")
            print("FAILED CHECKS:")
            for item in result["failed"]:
                details = item.get("details") or {}
                reason = details.get("reason") or details.get("error")
                if not reason:
                    if item["name"] == "MT5_AUTOTRADING_ALLOWED":
                        reason = "AUTO_TRADING_DISABLED_OR_TRADE_API_DISABLED"
                    elif item["name"] == "MT5_TERMINAL_CONNECTED":
                        reason = "MT5_TERMINAL_NOT_CONNECTED"
                    elif item["name"] == "DEMO_ACCOUNT":
                        reason = "CONNECTED_ACCOUNT_IS_NOT_DEMO"
                    else:
                        reason = "CHECK_FAILED"
                print(f" - {item['name']}: {reason} | details={details}")
        return result
    finally:
        connector.disconnect()


def run_live_demo_smoke(symbol, direction, volume, auto_close):
    """Modo `smoke`: envia UNA orden real en DEMO para validar la cadena.

    Args:
        symbol: instrumento a operar.
        direction: BUY o SELL.
        volume: lotes; 0 usa el minimo del simbolo.
        auto_close: cierra la posicion al terminar (recomendado).

    Vinculaciones:
        `services.live_demo_smoke_test_service.LiveDemoSmokeTestService`.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_execution import MT5ExecutionProvider
    from services.live_demo_smoke_test_service import (
        LiveDemoSmokeTestConfig,
        LiveDemoSmokeTestService,
    )

    connector = MT5Connector()
    repository = TradingRepository()
    try:
        connector.connect()
        service = LiveDemoSmokeTestService(
            execution_provider=MT5ExecutionProvider(connector),
            repository=repository,
            config=LiveDemoSmokeTestConfig(
                symbol=symbol,
                direction=direction,
                volume=volume,
                auto_close=auto_close,
                output_path=(
                    PROJECT_ROOT / "storage" / "exports" / "deriv_demo_smoke_report.xlsx"
                ),
            ),
        )
        result = service.run()
        print("=" * 72)
        print("DERIV DEMO LIVE SMOKE TEST")
        print("=" * 72)
        print("POSITION TICKET:", result["position_ticket"])
        print("EXECUTION ID:", result["execution_id"])
        print("BROKER POSITION FOUND:", result["broker_position_found"])
        print("SQLITE TRADE FOUND:", result["sqlite_trade_found"])
        print("CLOSED:", result["closed"])
        print("XLSX:", result["xlsx"])
        return result
    finally:
        connector.disconnect()


def _resolve_live_symbols(args):
    """
    Descubre símbolos dinámicamente para modos que usan MT5.

    Se crea una conexión temporal solamente para resolver la lista.
    Los motores vuelven a abrir su propia conexión para ejecutar.
    """
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider

    connector = MT5Connector()
    mt5_metadata_provider = MT5DataProvider(connector)
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider
    market_data_settings = ExternalMarketDataSettings.from_environment(
        getattr(args, "market_data_mode", None)
    )
    provider = build_market_data_provider(
        mt5_metadata_provider, settings=market_data_settings,
    )

    try:
        provider.connect()

        resolved = _resolve_symbols(
            provider,
            symbol=args.symbol,
            categories=args.categories,
        )

        # Las preferencias persistentes del módulo Instrumentos actúan como
        # selección predeterminada únicamente cuando el usuario no fuerza
        # --symbol ni --categories en la línea de comandos.
        if not args.symbol and not args.categories:
            try:
                repo = TradingRepository()
                pref = repo.latest_instrument_selection(source="DEMO")
            except Exception:
                pref = None

            if pref and pref.get("selected_symbols"):
                preferred = [str(s) for s in pref["selected_symbols"]]
                resolved_set = set(resolved)
                filtered = [s for s in preferred if s in resolved_set]

                # Si algún instrumento cambió de nombre/dejó de existir, no
                # bloqueamos el daemon. Se usan sólo los que siguen disponibles.
                if filtered:
                    print(
                        "Preferencias persistentes de instrumentos recuperadas "
                        f"desde SQLAlchemy ({len(filtered)}): {filtered}"
                    )
                    return filtered

        return resolved

    finally:
        provider.disconnect()





BOT_PROFILES = {
    # Perfil agregado conservado por compatibilidad. No se usa en el nuevo
    # coordinador dividido salvo que el usuario lo ejecute explícitamente.
    "SYNTHETICS": {
        "mode": "synthetic-daemon",
        "magic": 26082026,
        "categories": ["volatility", "boom", "crash", "step", "jump", "flip"],
    },
    "BOOM": {
        "mode": "boom-daemon",
        "magic": 26082101,
        "categories": ["boom"],
    },
    "CRASH": {
        "mode": "crash-daemon",
        "magic": 26082102,
        "categories": ["crash"],
    },
    "VOLATILITY": {
        "mode": "volatility-daemon",
        "magic": 26082103,
        "categories": ["volatility"],
    },
    # v99: el perfil anterior se conserva para compatibilidad/manual, pero el
    # multi-bot distribuye su universo entre cuatro procesos independientes.
    "VOLATILITY_1": {
        "mode": "volatility-1-daemon", "magic": 26082401,
        "categories": ["volatility"], "shard_index": 0, "shard_count": 4,
    },
    "VOLATILITY_2": {
        "mode": "volatility-2-daemon", "magic": 26082402,
        "categories": ["volatility"], "shard_index": 1, "shard_count": 4,
    },
    "VOLATILITY_3": {
        "mode": "volatility-3-daemon", "magic": 26082403,
        "categories": ["volatility"], "shard_index": 2, "shard_count": 4,
    },
    "VOLATILITY_4": {
        "mode": "volatility-4-daemon", "magic": 26082404,
        "categories": ["volatility"], "shard_index": 3, "shard_count": 4,
    },
    "STEP": {
        "mode": "step-daemon",
        "magic": 26082104,
        "categories": ["step"],
    },
    "JUMP": {
        "mode": "jump-daemon",
        "magic": 26082105,
        "categories": ["jump"],
    },
    "FLIP": {
        "mode": "flip-daemon",
        "magic": 26082106,
        "categories": ["flip"],
    },
    "FOREX": {
        "mode": "forex-daemon",
        "magic": 26082027,
        "categories": ["forex"],
    },
    "FOREX_1": {
        "mode": "forex-1-daemon",
        "magic": 26082201,
        "categories": ["forex"],
        "shard_index": 0,
        "shard_count": 4,
    },
    "FOREX_2": {
        "mode": "forex-2-daemon",
        "magic": 26082202,
        "categories": ["forex"],
        "shard_index": 1,
        "shard_count": 4,
    },
    "FOREX_3": {
        "mode": "forex-3-daemon",
        "magic": 26082203,
        "categories": ["forex"],
        "shard_index": 2,
        "shard_count": 4,
    },
    "FOREX_4": {
        "mode": "forex-4-daemon",
        "magic": 26082204,
        "categories": ["forex"],
        "shard_index": 3,
        "shard_count": 4,
    },
    "ORB": {
        "mode": "orb-daemon",
        "magic": 26082028,
        "categories": [],
    },
    "GOLD": {
        "mode": "gold-session-daemon",
        "magic": 26082029,
        "categories": [],
    },
    "IDX_OPEN": {
        "mode": "idx-open-daemon",
        "magic": 26082030,
        "categories": [],
    },
}

# FLIP remains available for explicit manual launch, but is excluded from
# every automatic worker group because Deriv Charts has no matching data.
SYNTHETIC_SPLIT_PROFILES = (
    "BOOM",
    "CRASH",
    "VOLATILITY",
    "STEP",
    "JUMP",
)

VOLATILITY_SHARD_PROFILES = (
    "VOLATILITY_1", "VOLATILITY_2", "VOLATILITY_3", "VOLATILITY_4",
)
MULTIBOT_SYNTHETIC_PROFILES = (
    "BOOM", "CRASH", *VOLATILITY_SHARD_PROFILES, "STEP", "JUMP",
)
FOREX_SPLIT_PROFILES = ("FOREX_1", "FOREX_2", "FOREX_3", "FOREX_4")
# v109: IDX_OPEN se retiró de la arquitectura multi-bot activa (desactivado
# a pedido del usuario, no eliminado). El perfil sigue existiendo en
# `BOT_PROFILES` y toda su lógica (estrategia, worker, dashboard) permanece
# intacta por si se quiere reactivar: solo se excluye de la lista que arranca
# automáticamente con `multi-bot-daemon`/`unified-multibot-daemon`, y su
# `LiveTradingConfig.idx_open_enabled` quedó en `False` por defecto (ver
# ese campo en `strategy/execution/live_trading_engine.py`). Para reactivar:
# volver a incluir "IDX_OPEN" aquí y restaurar `idx_open_enabled=True`.
FULL_MULTI_BOT_PROFILES = (
    *MULTIBOT_SYNTHETIC_PROFILES,
    *FOREX_SPLIT_PROFILES,
    "GOLD", "ORB",
)


def _assert_synthetic_split_architecture():
    """Falla temprano si se rompe la separación 1 familia = 1 proceso."""
    expected = {
        "BOOM": ("boom-daemon", 26082101, ("boom",)),
        "CRASH": ("crash-daemon", 26082102, ("crash",)),
        "VOLATILITY": ("volatility-daemon", 26082103, ("volatility",)),
        "STEP": ("step-daemon", 26082104, ("step",)),
        "JUMP": ("jump-daemon", 26082105, ("jump",)),
    }
    if tuple(SYNTHETIC_SPLIT_PROFILES) != tuple(expected):
        raise RuntimeError("SYNTHETIC_SPLIT_ARCHITECTURE_ERROR: perfiles alterados.")
    seen_modes, seen_magics = set(), set()
    for profile, (mode, magic, categories) in expected.items():
        spec = BOT_PROFILES.get(profile) or {}
        actual = (spec.get("mode"), spec.get("magic"), tuple(spec.get("categories") or ()))
        if actual != (mode, magic, categories):
            raise RuntimeError(f"SYNTHETIC_SPLIT_ARCHITECTURE_ERROR: {profile}={actual}.")
        if mode in seen_modes or magic in seen_magics:
            raise RuntimeError(f"SYNTHETIC_SPLIT_ARCHITECTURE_ERROR: duplicado en {profile}.")
        seen_modes.add(mode); seen_magics.add(magic)
    return True


def _assert_full_multibot_architecture(profiles):
    """Garantiza un solo coordinador con todos los workers esperados y únicos."""
    profiles = tuple(str(p).upper() for p in (profiles or ()))
    expected = tuple(FULL_MULTI_BOT_PROFILES)
    if profiles != expected:
        raise RuntimeError(
            f"FULL_MULTIBOT_ARCHITECTURE_ERROR: profiles={profiles}, expected={expected}"
        )
    modes = [str(BOT_PROFILES[p]["mode"]) for p in profiles]
    magics = [int(BOT_PROFILES[p]["magic"]) for p in profiles]
    if len(set(modes)) != len(modes) or len(set(magics)) != len(magics):
        raise RuntimeError("FULL_MULTIBOT_ARCHITECTURE_ERROR: mode o magic duplicado")
    if BOT_PROFILES["GOLD"] != {
        "mode": "gold-session-daemon", "magic": 26082029, "categories": []
    }:
        raise RuntimeError("FULL_MULTIBOT_ARCHITECTURE_ERROR: perfil GOLD alterado")
    return True


def _selection_profile_for_bot(profile: str) -> str:
    """Traduce el perfil de un worker a su familia de instrumentos.

    GOLD comparte universo con ORB y por eso colapsa a esa selección. IDX_OPEN
    tiene su propia selección persistente independiente en /instruments (ver
    _SELECTION_PROFILES en el dashboard), asi que se mapea a si mismo.
    """
    profile = str(profile or "").upper()
    if profile.startswith("FOREX"): return "FOREX"
    if profile == "IDX_OPEN": return "IDX_OPEN"
    if profile in {"ORB", "GOLD"}: return "ORB"
    return "SYNTHETICS"



def _stable_symbol_shard(symbols, shard_index: int, shard_count: int):
    """Distribuye símbolos de forma determinista y estable entre workers."""
    shard_count = max(1, int(shard_count))
    shard_index = int(shard_index)
    ordered = sorted({str(s) for s in symbols if s}, key=lambda s: s.upper())
    return [s for i, s in enumerate(ordered) if i % shard_count == shard_index]


def _forex_native_family_key(symbol):
    """Agrupa contratos MT5 que comparten el mismo mercado Deriv.

    No se elimina ninguna variante de ejecución: el usuario puede seleccionar
    el contrato standard o micro según su lotaje. La clave sólo garantiza que
    ambas variantes pertenezcan al mismo worker y no dupliquen el análisis
    entre procesos distintos.
    """
    normalized = "".join(ch for ch in str(symbol).casefold() if ch.isalnum())
    for suffix in ("micro", "mini", "pro", "raw"):
        if normalized.endswith(suffix):
            return normalized[:-len(suffix)]
    return normalized


def _stable_grouped_symbol_shard(symbols, shard_index: int, shard_count: int, key):
    """Reparte familias completas sin separar sus variantes de ejecución."""
    shard_count = max(1, int(shard_count))
    shard_index = int(shard_index)
    groups = {}
    for symbol in sorted({str(s) for s in symbols if s}, key=str.casefold):
        groups.setdefault(str(key(symbol)), []).append(symbol)
    selected_keys = {
        group_key
        for index, group_key in enumerate(sorted(groups, key=str.casefold))
        if index % shard_count == shard_index
    }
    return [
        symbol
        for group_key in sorted(selected_keys, key=str.casefold)
        for symbol in groups[group_key]
    ]


def _resolve_live_symbols_for_profile(args, profile: str):
    """Resuelve únicamente el universo perteneciente al bot solicitado."""
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider

    profile = str(profile).upper()
    if profile not in BOT_PROFILES:
        raise ValueError(f"Perfil de bot desconocido: {profile}")

    connector = MT5Connector()
    provider = MT5DataProvider(connector)
    try:
        provider.connect()
        manager = InstrumentManager(provider.connector)
        if profile == "ORB":
            universe = sorted(set(discover_orb_symbols(provider)))
        elif profile == "GOLD":
            # El worker GOLD comparte el mismo universo completo que ORB
            # (Oro, Plata, Petroleo e indices US). Los niveles de cuarto
            # (25/50/75/100) solo se aplican internamente para XAUUSD/
            # microXAUUSD; el resto de instrumentos opera sin esa confluencia.
            universe = sorted(set(discover_orb_symbols(provider)))
        elif profile == "IDX_OPEN":
            # Apertura Indices Bursatiles: solo los 3 indices US (Wall Street
            # 30, US Tech 100, US SP 500), reutilizando el mismo descubrimiento
            # de ORB pero filtrado a is_orb_index_symbol.
            universe = sorted({
                symbol for symbol in discover_orb_symbols(provider)
                if is_orb_index_symbol(symbol)
            })
        else:
            universe = manager.get_active_symbols(
                categories=BOT_PROFILES[profile]["categories"]
            )

        spec = BOT_PROFILES[profile]
        if spec.get("shard_count"):
            shard_args = (
                universe,
                int(spec.get("shard_index", 0)),
                int(spec.get("shard_count", 1)),
            )
            universe = (
                _stable_grouped_symbol_shard(*shard_args, key=_forex_native_family_key)
                if profile.startswith("FOREX")
                else _stable_symbol_shard(*shard_args)
            )

        if args.symbol:
            exact = provider.ensure_symbol(args.symbol)
            if exact not in set(universe):
                raise ValueError(
                    f"El símbolo {exact} no pertenece al bot {profile}."
                )
            return [exact]

        if not universe:
            return []

        # v56: cada worker arranca con TODO su universo. La preferencia
        # persistente del perfil se relee en cada ciclo, sin reiniciar el bot.
        return universe
    finally:
        provider.disconnect()


def _build_multi_bot_dashboard_catalog(profiles):
    """Descubre el catálogo completo que debe mostrar el dashboard coordinador."""
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider

    connector = MT5Connector()
    provider = MT5DataProvider(connector)
    categorized = {}
    try:
        provider.connect()
        manager = InstrumentManager(provider.connector)

        for profile in profiles:
            spec = BOT_PROFILES[profile]
            if profile == "ORB":
                for symbol in discover_orb_symbols(provider):
                    market = classify_orb_market(symbol) or "ORB"
                    categorized.setdefault(
                        f"orb_ny_{str(market).lower()}",
                        [],
                    ).append(symbol)
                continue
            if profile == "GOLD":
                # XAUUSD ya aparece en la categoría visual ORB; el perfil GOLD
                # reutiliza esa selección sin duplicar el instrumento en UI.
                continue
            if profile == "IDX_OPEN":
                # Categoria visual propia en /instruments, ademas de aparecer
                # bajo ORB (mismos simbolos, seleccion independiente por perfil).
                for symbol in discover_orb_symbols(provider):
                    if is_orb_index_symbol(symbol):
                        categorized.setdefault("idx_open_indices", []).append(symbol)
                continue

            for category in spec.get("categories", []):
                symbols = manager.get_active_symbols(categories=[category])
                if symbols:
                    categorized.setdefault(category, []).extend(symbols)

        # Eliminar duplicados sin alterar el nombre real del broker.
        for category, symbols in list(categorized.items()):
            categorized[category] = sorted(set(str(s) for s in symbols if s))
        return categorized
    finally:
        provider.disconnect()


def _recover_empty_synthetic_selection(repo, catalog, profiles):
    """Restaura el catálogo sintético si su preferencia persistida quedó vacía."""
    active_profiles = {str(profile or "").upper() for profile in (profiles or [])}
    if not active_profiles.intersection(SYNTHETIC_SPLIT_PROFILES):
        return None
    reader = getattr(repo, "latest_instrument_selection_profile", None)
    writer = getattr(repo, "save_instrument_selection_profile", None)
    if not callable(reader) or not callable(writer):
        return None
    preference = reader("SYNTHETICS", source="DEMO")
    if preference is None or preference.get("selected_symbols"):
        return None
    synthetic_symbols = sorted(
        {
            str(symbol)
            for category, symbols in (catalog or {}).items()
            if str(category).lower() != "forex"
            and not str(category).lower().startswith("orb_ny_")
            for symbol in (symbols or [])
            if symbol
        },
        key=str.casefold,
    )
    if not synthetic_symbols:
        return None
    saved = writer(
        synthetic_symbols, selection_profile="SYNTHETICS", source="DEMO"
    )
    try:
        repo.save_audit_event(
            "EMPTY_SYNTHETIC_SELECTION_RECOVERED",
            source="DEMO",
            action="RESTORED_ALL_SYNTHETIC_SYMBOLS",
            reason="El coordinador no puede iniciar seis familias con SYNTHETICS vacío",
            payload={
                "symbols_restored": len(synthetic_symbols),
                "previous_version": preference.get("version"),
                "new_version": saved.get("version"),
                "version": DAEMONBLACKFX_VERSION,
            },
        )
    except Exception:
        pass
    print(
        "[RECUPERACIÓN] SYNTHETICS estaba vacío: "
        f"se habilitaron {len(synthetic_symbols)} instrumentos del catálogo."
    )
    return saved


def _assert_v53_runtime_compatibility(repo):
    """Falla temprano si la carpeta contiene módulos de versiones mezcladas."""
    missing = []
    if not hasattr(repo, "upsert_worker_runtime_state"):
        missing.append("TradingRepository.upsert_worker_runtime_state")
    if not hasattr(repo, "worker_runtime_states"):
        missing.append("TradingRepository.worker_runtime_states")

    try:
        from reporting.trade_report_exporter import TradeReportExporter
        if not hasattr(TradeReportExporter, "_compact_audit_dataframe"):
            missing.append("TradeReportExporter._compact_audit_dataframe")
    except Exception as exc:
        missing.append(f"TradeReportExporter import: {exc}")

    if missing:
        raise RuntimeError(
            "INSTALACION_INCONSISTENTE_V53: se detectaron archivos de versiones mezcladas. "
            "Extrae el ZIP v53 en una carpeta NUEVA y no sobre una instalación anterior. "
            "Faltan: " + ", ".join(missing)
        )

    # Verifica que la tabla nueva pueda escribirse/leerse realmente.
    probe_profile = "V53_PROBE"
    try:
        repo.upsert_worker_runtime_state(
            probe_profile,
            53000000,
            source="SYSTEM",
            status="PROBE",
            last_action="SCHEMA_CHECK",
            last_reason=DAEMONBLACKFX_VERSION,
            details={"version": DAEMONBLACKFX_VERSION},
        )
        rows = repo.worker_runtime_states(source="SYSTEM")
        if not any(row.get("bot_profile") == probe_profile for row in rows):
            raise RuntimeError("worker_runtime_states no devolvio el registro de prueba")
    except Exception as exc:
        raise RuntimeError(
            "RUNTIME_DB_SCHEMA_ERROR: no fue posible validar worker_runtime_states. "
            f"Detalle: {exc}"
        ) from exc


def _resolve_symbols_for_profile_shared(provider, repo, profile: str):
    """Resuelve el universo de un perfil usando una conexión MT5 ya abierta."""
    profile = str(profile or "").upper()
    spec = BOT_PROFILES[profile]
    manager = InstrumentManager(provider.connector)

    if profile == "ORB":
        universe = list(discover_orb_symbols(provider))
    elif profile == "GOLD":
        # Mismo universo compartido que ORB; ver nota en
        # _resolve_live_symbols_for_profile sobre niveles de cuarto.
        universe = list(discover_orb_symbols(provider))
    elif profile == "IDX_OPEN":
        # Apertura Indices Bursatiles: solo los 3 indices US.
        universe = [
            s for s in discover_orb_symbols(provider) if is_orb_index_symbol(s)
        ]
    elif profile.startswith("FOREX"):
        try:
            universe = list(manager.discovery.get_tradeable_forex())
        except Exception:
            universe = list(manager.get_active_symbols(categories=["forex"]))
    else:
        universe = []
        for category in spec.get("categories", []):
            universe.extend(manager.get_active_symbols(categories=[category]) or [])

    universe = sorted({str(s) for s in universe if s}, key=str.casefold)
    if spec.get("shard_count"):
        universe = _stable_symbol_shard(
            universe,
            int(spec.get("shard_index") or 0),
            int(spec.get("shard_count") or 1),
        )
    selection_profile = _selection_profile_for_bot(profile)
    reader = getattr(repo, "latest_instrument_selection_profile", None)
    pref = None
    if callable(reader):
        try:
            pref = reader(selection_profile, source="DEMO")
        except Exception:
            pref = None
    if pref is not None:
        selected = {str(s) for s in (pref.get("selected_symbols") or [])}
        universe = [s for s in universe if s in selected]
    return universe


def _run_startup_database_maintenance(repo, args):
    """Aplica retención antes de crear dashboard/workers del coordinador."""
    try:
        maintenance = repo.maintain_operational_audits(
            retention_days=getattr(args, "audit_retention_days", 14),
            max_rows=getattr(args, "audit_retention_max_rows", 250_000),
            checkpoint_mode="TRUNCATE",
        )
        print(
            "[DB MAINTENANCE] "
            f"deleted={maintenance['retention']['deleted_total']} "
            f"checkpoint={maintenance['checkpoint']['mode']} "
            f"db={maintenance['database']['path']}"
        )
        repo.save_audit_event(
            "DATABASE_MAINTENANCE",
            source="DEMO",
            action="AUDIT_RETENTION_APPLIED",
            payload=maintenance,
        )
        return maintenance
    except Exception as exc:
        # La retención es mantenimiento defensivo: nunca impide arrancar trading.
        print(f"[DB MAINTENANCE WARNING] {exc}", file=sys.stderr)
        return None


def run_unified_multibot_daemon(args, profiles=None):
    """v76: un solo proceso con workers lógicos independientes."""
    _warn_possible_parallel_daemon_instances()
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider
    from brokers.mt5_execution import MT5ExecutionProvider
    from brokers.mt5_trade_executor import MT5TradeExecutor
    from dashboard.realtime_dashboard import RealtimeDashboardService
    from reporting.console_reporting_service import ConsoleReportingConfig, ConsoleReportingService
    from reporting.trade_reporting_service import TradeReportingConfig, TradeReportingService
    from trade_lifecycle_manager import TradeLifecycleManager

    profiles = tuple(profiles or FULL_MULTI_BOT_PROFILES)
    if profiles == tuple(FULL_MULTI_BOT_PROFILES):
        _assert_full_multibot_architecture(profiles)
    repo = TradingRepository()
    _assert_v53_runtime_compatibility(repo)
    _run_startup_database_maintenance(repo, args)

    connector = MT5Connector()
    mt5_metadata_provider = MT5DataProvider(connector)
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider
    market_data_settings = ExternalMarketDataSettings.from_environment(
        getattr(args, "market_data_mode", None)
    )
    provider = build_market_data_provider(
        mt5_metadata_provider, settings=market_data_settings,
    )
    execution_provider = MT5ExecutionProvider(connector)
    reporting = TradeReportingService(
        repository=repo,
        config=TradeReportingConfig(
            source="DEMO",
            output_path=PROJECT_ROOT / "storage" / "exports" / "deriv_demo_trading_report.xlsx",
            auto_export=False,
            broker="Deriv-Demo",
        ),
    )
    dashboard = RealtimeDashboardService(
        repository=repo,
        host="127.0.0.1",
        port=int(args.dashboard_port),
    )

    engines = {}
    symbols_by_profile = {}
    next_due = {}
    last_visual_by_profile = {}
    last_dashboard_heartbeat = 0.0
    pid = os.getpid()

    try:
        provider.connect()
        manager = InstrumentManager(provider.connector)

        categorized = {}
        for profile in profiles:
            spec = BOT_PROFILES[profile]
            if profile == "ORB":
                for symbol in discover_orb_symbols(provider):
                    market = classify_orb_market(symbol) or "ORB"
                    categorized.setdefault(f"orb_ny_{str(market).lower()}", []).append(symbol)
            elif profile.startswith("FOREX"):
                if "forex" not in categorized:
                    try:
                        categorized["forex"] = list(manager.discovery.get_tradeable_forex())
                    except Exception:
                        categorized["forex"] = list(manager.get_active_symbols(categories=["forex"]))
            else:
                for category in spec.get("categories", []):
                    categorized.setdefault(category, []).extend(
                        manager.get_active_symbols(categories=[category]) or []
                    )
        categorized = {
            k: sorted({str(x) for x in v if x}, key=str.casefold)
            for k, v in categorized.items()
        }
        dashboard.set_instrument_catalog(categorized, selected_symbols=None)
        dashboard_url = dashboard.start(live=True)
        dashboard.update_status("MULTIBOT UNIFICADO ACTIVO · 1 PROCESO")
        print(f"Dashboard central: {dashboard_url}")
        print(f"Instrumentos: {dashboard.instruments_url}")
        print(f"Cuenta activa: {dashboard.account_url}")

        for profile in profiles:
            spec = BOT_PROFILES[profile]
            symbols = _resolve_symbols_for_profile_shared(provider, repo, profile)
            if symbols and hasattr(provider, "prepare_symbols"):
                symbols = provider.prepare_symbols(symbols)
            symbols_by_profile[profile] = list(symbols)

            trade_executor = MT5TradeExecutor(
                execution_provider=execution_provider,
                magic=int(spec["magic"]),
                deviation=20,
            )
            lifecycle = TradeLifecycleManager(
                trade_executor=trade_executor,
                reporting_service=reporting,
            )
            console = ConsoleReportingService(
                ConsoleReportingConfig(verbose=args.verbose, debug=args.debug)
            )
            config = LiveTradingConfig(
                source="DEMO",
                entry_timeframe=args.timeframe,
                risk_percent=args.risk_percent,
                bot_profile=profile,
                magic=int(spec["magic"]),
                min_rr=args.min_rr,
                pre_fill_risk_buffer=0.01,
                min_actual_risk_ratio=0.97,
                execution_enabled=args.execute,
                orb_enabled=(profile == "ORB"),
                forex_event_timeframe="M5",
                first_target_rr=1.0,
                second_target_rr=2.0,
                single_entry_target_rr=2.0,
                runner_extension_enabled=bool(
                    not profile.startswith(("FOREX", "VOLATILITY"))
                    and profile not in {"SYNTHETICS", "BOOM", "CRASH", "STEP", "JUMP", "FLIP", "ORB"}
                ),
                runner_extension_first_trigger_rr=2.0,
                runner_extension_first_lock_rr=1.0,
                runner_extension_second_trigger_rr=3.0,
                runner_extension_second_lock_rr=2.0,
                runner_extension_max_target_rr=2.0,
                jump_strict_filter_enabled=True,
                jump_min_confirmation_ratio=0.90,
                jump_min_trade_score=90.0,
                jump_allow_single_fallback=False,
                chart_pattern_conflict_min_margin=args.chart_pattern_conflict_min_margin,
                hard_risk_tolerance=args.hard_risk_tolerance,
                recoverable_quarantine_extra_tolerance=args.recoverable_quarantine_extra_tolerance,
            )
            engines[profile] = LiveTradingEngine(
                provider,
                repo,
                config=config,
                executor=execution_provider,
                lifecycle_manager=lifecycle,
                reporting_service=reporting,
                console_reporter=console,
                dashboard_service=None,
            )
            next_due[profile] = time.monotonic() + (0.15 * len(next_due))
            last_visual_by_profile[profile] = 0.0
            repo.upsert_worker_runtime_state(
                profile,
                int(spec["magic"]),
                source="DEMO",
                status="RUNNING_UNIFIED",
                pid=pid,
                symbols_total=len(symbols),
                symbols_processed=0,
                current_symbol=None,
                last_action="UNIFIED_WORKER_READY",
                last_reason="v76: worker lógico dentro del proceso MultiBot",
                details={"version": DAEMONBLACKFX_VERSION, "runtime_mode": "UNIFIED_PROCESS"},
            )

        account = execution_provider.assert_demo_account()
        print(
            f"DAEMONBLACKFX VERSION: {DAEMONBLACKFX_VERSION} | "
            f"MULTIBOT UNIFICADO PID={pid} | perfiles={len(engines)}"
        )
        print(
            f"MARKET DATA: {market_data_settings.mode.upper()} · "
            f"PROVIDER={market_data_settings.provider.upper()} · MT5=EXECUTION_ONLY"
        )
        print(f"Cuenta DEMO: {account.get('login')} · {account.get('server')}")

        last_report = 0.0
        while True:
            now = time.monotonic()
            did_work = False

            # Las selecciones pueden cambiar desde /instruments sin reiniciar.
            for profile, engine in engines.items():
                if now < next_due.get(profile, 0.0):
                    continue
                did_work = True
                spec = BOT_PROFILES[profile]
                try:
                    symbols = _resolve_symbols_for_profile_shared(provider, repo, profile)
                    if symbols and hasattr(provider, "prepare_symbols"):
                        symbols = provider.prepare_symbols(symbols)
                    symbols_by_profile[profile] = list(symbols)

                    due_symbols = engine._selected_cycle_symbols(symbols)
                    due_symbols = engine._forex_due_symbols(due_symbols)
                    monitor = engine._monitor_break_even_positions()
                    current_audit = engine._refresh_current_strategy_views()

                    # Actualiza gráficos de auditoría sin crear otro servidor/front.
                    # v109: cadencia 30s->60s y menos velas por snapshot (punto 3
                    # de la optimización de memoria: reduce el tamaño del JSON
                    # persistido en trade_visual_audits y servido por /api/state).
                    visual_updated = 0
                    if time.monotonic() - float(last_visual_by_profile.get(profile) or 0.0) >= 60.0:
                        try:
                            charts = engine._dashboard_chart_snapshots(candle_count=80)
                            owned = [
                                t for t in (repo.open_trades(source="DEMO") or [])
                                if isinstance(t, dict) and engine._trade_owned_by_current_bot(t)
                            ]
                            for trade in owned:
                                trade_id = trade.get("id")
                                symbol = str(trade.get("instrument") or "")
                                chart = charts.get(symbol) or {}
                                if trade_id and chart:
                                    repo.upsert_trade_visual_audit(
                                        int(trade_id),
                                        instrument=symbol,
                                        bot_profile=profile,
                                        daemon_magic=int(spec["magic"]),
                                        broker_position_ticket=trade.get("broker_position_ticket"),
                                        latest_chart=chart,
                                        source="DEMO",
                                    )
                                    visual_updated += 1
                            last_visual_by_profile[profile] = time.monotonic()
                        except Exception as exc:
                            if args.debug:
                                print(f"[{profile}] VISUAL AUDIT ERROR: {exc}")

                    results = engine.process_symbols(
                        due_symbols,
                        sync_before_execution=True,
                    ) if due_symbols else []
                    engine._commit_forex_processed_symbols(results)

                    session = getattr(engine, "_analysis_session_diagnostics", {})
                    last_action = (
                        str((results[-1] or {}).get("action") or "WAITING")
                        if results else "WAITING_NEXT_EVENT"
                    )
                    repo.upsert_worker_runtime_state(
                        profile,
                        int(spec["magic"]),
                        source="DEMO",
                        status=session.get("state") if not session.get("active", True) else "RUNNING_UNIFIED",
                        pid=pid,
                        symbols_total=len(symbols),
                        symbols_processed=len(results),
                        current_symbol=None,
                        last_action=last_action,
                        last_reason=(f"Próxima apertura UTC: {session.get('next_activation')}; gestión de posiciones activa"
                                     if not session.get("active", True) else "Proceso único MultiBot"),
                        details={
                            "version": DAEMONBLACKFX_VERSION,
                            "runtime_mode": "UNIFIED_PROCESS",
                            "monitor": monitor,
                            "current_audit": current_audit,
                            "visual_updated": visual_updated,
                        },
                    )
                except Exception as exc:
                    repo.upsert_worker_runtime_state(
                        profile,
                        int(spec["magic"]),
                        source="DEMO",
                        status="ERROR",
                        pid=pid,
                        symbols_total=len(symbols_by_profile.get(profile) or []),
                        symbols_processed=0,
                        current_symbol=None,
                        last_action="UNIFIED_WORKER_ERROR",
                        last_reason=str(exc),
                        details={"version": DAEMONBLACKFX_VERSION, "runtime_mode": "UNIFIED_PROCESS"},
                    )
                    if args.debug:
                        print(f"[{profile}] ERROR: {exc}")

                if profile.startswith("FOREX") or profile == "GOLD":
                    delay = max(2.0, float(getattr(engine.config, "forex_event_poll_seconds", 10.0)))
                elif profile == "ORB":
                    delay = min(max(5.0, float(args.interval)), 10.0)
                else:
                    delay = max(1.0, float(args.interval))
                next_due[profile] = time.monotonic() + delay

            if time.monotonic() - last_report >= max(10.0, float(args.report_interval)):
                try:
                    reporting.export_now()
                except Exception as exc:
                    if args.debug:
                        print(f"[REPORT] {exc}")
                last_report = time.monotonic()

            if time.monotonic() - last_dashboard_heartbeat >= 2.0:
                dashboard.mark_live()
                last_dashboard_heartbeat = time.monotonic()
            if not did_work:
                time.sleep(0.25)

    except KeyboardInterrupt:
        print("MultiBot unificado detenido por el usuario.")
    finally:
        try:
            dashboard.mark_offline("MULTIBOT UNIFICADO DESCONECTADO · ESTADO PERSISTIDO")
            dashboard.stop()
        except Exception:
            pass
        try:
            provider.disconnect()
        except Exception:
            pass


def _warn_possible_parallel_daemon_instances():
    """Best-effort warning for stale DaemonBlackFx Python processes on Windows."""
    if os.name != "nt":
        return
    try:
        completed = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "Get-CimInstance Win32_Process | "
                "Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -match 'app.main'} | "
                "Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        raw = (completed.stdout or "").strip()
        if not raw:
            return
        import json as _json
        data = _json.loads(raw)
        rows = data if isinstance(data, list) else [data]
        rows = [r for r in rows if isinstance(r, dict)]
        current_pid = os.getpid()
        others = [r for r in rows if int(r.get("ProcessId") or -1) != current_pid]
        if others:
            print(
                "[ADVERTENCIA] Se detectaron otras instancias Python de DaemonBlackFx "
                "ejecutándose en paralelo. Esto puede aumentar CPU, lecturas MT5 y "
                "contención SQLite."
            )
            for row in others[:12]:
                print(
                    f"  PID={row.get('ProcessId')} | "
                    f"{str(row.get('CommandLine') or '')[:180]}"
                )
            print(
                "Recomendación: cerrar procesos antiguos antes de iniciar el MultiBot actual."
            )
    except Exception:
        return


class _MultiBotInstanceGuard:
    """Bloqueo atómico que permite un solo coordinador por proyecto.

    En Windows usa un mutex del sistema operativo, que desaparece incluso si el
    proceso termina abruptamente. En POSIX usa ``flock`` sobre un archivo
    persistente. El JSON es sólo diagnóstico; nunca decide por sí solo si una
    instancia está viva, por lo que un PID antiguo no bloquea el arranque.
    """

    def __init__(self, project_root: Path):
        """Prepara el nombre del mutex y la ruta del estado de diagnostico.

        El nombre del mutex se deriva de un hash de la ruta del proyecto, de
        modo que dos copias del codigo en carpetas distintas puedan convivir,
        pero nunca dos daemons sobre la misma.
        """
        self.project_root = Path(project_root).resolve()
        runtime_dir = self.project_root / "storage" / "runtime"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = runtime_dir / "multi_bot_daemon.instance.json"
        identity = hashlib.sha256(str(self.project_root).lower().encode("utf-8")).hexdigest()[:20]
        self.mutex_name = f"Local\\DaemonBlackFxMultiBot_{identity}"
        self._handle = None
        self._file = None
        self._released = False

    def _owner(self):
        """Lee el JSON de diagnostico del propietario actual.

        Solo informativo: devuelve `{}` ante cualquier error, para que un
        fichero corrupto jamas impida arrancar.
        """
        try:
            value = json.loads(self.state_path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def _already_running(self):
        """Aborta el arranque informando del coordinador que ya tiene el lock.

        Raises:
            SystemExit: siempre. Se sale ANTES de crear ningun worker, para no
                dejar procesos huerfanos operando la misma cuenta.
        """
        owner = self._owner()
        pid = owner.get("pid") or "DESCONOCIDO"
        started_at = owner.get("started_at") or "DESCONOCIDO"
        command = owner.get("command") or ""
        raise SystemExit(
            "MULTIBOT_ALREADY_RUNNING: ya existe un coordinador activo "
            f"PID={pid} iniciado={started_at}.\n"
            f"Comando propietario: {command}\n"
            "La segunda instancia fue cancelada antes de crear workers."
        )

    def acquire(self):
        """Toma el bloqueo de instancia unica y registra su liberacion.

        Windows: mutex con nombre; `ERROR_ALREADY_EXISTS` (183) indica que otro
        coordinador esta vivo. POSIX: `flock` no bloqueante.

        Ambos mecanismos los libera el sistema operativo si el proceso muere de
        golpe, a diferencia de un fichero PID, que quedaria obsoleto.

        Returns:
            self, para encadenar.

        Raises:
            SystemExit: si ya hay otro coordinador.
            OSError: si el mutex no se puede crear.
        """
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateMutexW.argtypes = (wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR)
            kernel32.CreateMutexW.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle.restype = wintypes.BOOL
            handle = kernel32.CreateMutexW(None, False, self.mutex_name)
            if not handle:
                raise OSError(ctypes.get_last_error(), "No fue posible crear el mutex MultiBot")
            if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
                kernel32.CloseHandle(handle)
                self._already_running()
            self._handle = (kernel32, handle)
        else:
            import fcntl

            lock_path = self.state_path.with_suffix(".lock")
            self._file = open(lock_path, "a+", encoding="utf-8")
            try:
                fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                self._file.close()
                self._file = None
                self._already_running()

        state = {
            "pid": os.getpid(),
            "started_at": datetime.now().astimezone().isoformat(),
            "project_root": str(self.project_root),
            "command": subprocess.list2cmdline(sys.argv),
            "version": DAEMONBLACKFX_VERSION,
            "active": True,
        }
        self.state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        atexit.register(self.release)
        return self

    def release(self):
        """Libera el bloqueo y marca el estado como inactivo.

        Idempotente (`_released`), porque se invoca tanto de forma explicita
        como desde `atexit`. Solo actualiza el JSON si el PID registrado es el
        propio, para no pisar el estado de otro coordinador.
        """
        if self._released:
            return
        self._released = True
        try:
            state = self._owner()
            if int(state.get("pid") or -1) == os.getpid():
                state["active"] = False
                state["stopped_at"] = datetime.now().astimezone().isoformat()
                self.state_path.write_text(
                    json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8"
                )
        except Exception:
            pass
        if self._handle is not None:
            kernel32, handle = self._handle
            try:
                kernel32.CloseHandle(handle)
            except Exception:
                pass
            self._handle = None
        if self._file is not None:
            try:
                self._file.close()
            except Exception:
                pass
            self._file = None


def _acquire_multibot_instance_guard():
    """Obtiene el bloqueo de coordinador y descarta instancias heredadas.

    Doble control: el mutex protege frente a versiones actuales, y el rastreo
    de procesos en Windows detecta coordinadores de versiones antiguas que no
    conocen el mutex. Sin esto, dos daemons podrian operar la misma cuenta.

    Returns:
        `_MultiBotInstanceGuard` ya adquirido.

    Raises:
        SystemExit: si se detecta otro coordinador.
    """
    guard = _MultiBotInstanceGuard(PROJECT_ROOT).acquire()
    legacy = _find_other_multibot_coordinators_windows()
    if legacy:
        # Un coordinador v89 (o anterior) no conoce el mutex de v90. El mutex
        # protege la carrera entre versiones nuevas y este segundo control
        # impide convivir con procesos heredados ya activos.
        guard.release()
        rows = "\n".join(
            f"  PID={row.get('ProcessId')} | {str(row.get('CommandLine') or '')[:220]}"
            for row in legacy
        )
        raise SystemExit(
            "MULTIBOT_LEGACY_INSTANCE_DETECTED: existe otro coordinador "
            "multi-bot-daemon que no posee el bloqueo actual.\n"
            f"{rows}\n"
            "El nuevo arranque fue cancelado antes de crear dashboard o workers. "
            "Detenga el PID anterior y vuelva a ejecutar el comando."
        )
    return guard


def _find_other_multibot_coordinators_windows():
    """Devuelve coordinadores externos, excluyendo todo el árbol lanzador actual."""
    if os.name != "nt":
        return []
    try:
        completed = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                "Get-CimInstance Win32_Process | "
                "Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine | "
                "ConvertTo-Json -Compress",
            ],
            capture_output=True,
            text=True,
            timeout=8,
        )
        raw = (completed.stdout or "").strip()
        if not raw:
            return []
        data = json.loads(raw)
        rows = data if isinstance(data, list) else [data]
        return _filter_external_multibot_coordinators(
            rows,
            current_pid=os.getpid(),
            parent_pid=os.getppid(),
        )
    except Exception as exc:
        # Fallar cerrado es preferible: sin esta validación podríamos volver a
        # duplicar órdenes. El mensaje permite corregir PowerShell/CIM.
        raise SystemExit(
            "MULTIBOT_INSTANCE_SCAN_FAILED: no fue posible validar procesos "
            f"multi-bot-daemon existentes ({exc}). Arranque cancelado por seguridad."
        ) from exc


def _filter_external_multibot_coordinators(rows, current_pid, parent_pid):
    """Separa coordinadores reales de los launchers del intérprete actual.

    En algunos virtualenv de Windows ``python.exe`` actúa como launcher y crea
    otro proceso Python con la misma línea de comando. Ese launcher es ancestro
    del intérprete actual, no una segunda instancia. Se reconstruye toda la
    cadena ParentProcessId antes de evaluar candidatos.
    """
    normalized = [row for row in rows if isinstance(row, dict)]
    parent_by_pid = {}
    for row in normalized:
        try:
            parent_by_pid[int(row.get("ProcessId"))] = int(row.get("ParentProcessId") or 0)
        except (TypeError, ValueError):
            continue

    own_tree = {int(current_pid), int(parent_pid)}
    pending = list(own_tree)
    while pending:
        pid = pending.pop()
        ancestor = int(parent_by_pid.get(pid) or 0)
        if ancestor > 0 and ancestor not in own_tree:
            own_tree.add(ancestor)
            pending.append(ancestor)

    external = []
    for row in normalized:
        try:
            pid = int(row.get("ProcessId") or -1)
        except (TypeError, ValueError):
            continue
        if pid in own_tree:
            continue
        name = str(row.get("Name") or "").lower()
        command = str(row.get("CommandLine") or "")
        if name not in {"python.exe", "pythonw.exe"}:
            continue
        if not re.search(r"(?:^|\s)(?:-m\s+)?app\.main(?:\s|$)", command, re.IGNORECASE):
            continue
        if not re.search(r"--mode(?:=|\s+)multi-bot-daemon(?:\s|$)", command, re.IGNORECASE):
            continue
        external.append(row)
    return external


def run_multi_bot_daemon(args, profiles=None):
    """Orquesta perfiles como procesos independientes.

    Los workers escriben sólo DB. Este coordinador es el único escritor periódico
    del XLSX consolidado para evitar colisiones entre procesos.
    """
    _warn_possible_parallel_daemon_instances()
    from reporting.trade_reporting_service import TradeReportingConfig, TradeReportingService

    logs_dir = PROJECT_ROOT / "storage" / "logs" / "bots"
    logs_dir.mkdir(parents=True, exist_ok=True)

    repo = TradingRepository()
    _assert_v53_runtime_compatibility(repo)
    _run_startup_database_maintenance(repo, args)
    reporting = TradeReportingService(
        repository=repo,
        config=TradeReportingConfig(
            source="DEMO",
            output_path=PROJECT_ROOT / "storage" / "exports" / "deriv_demo_trading_report.xlsx",
            auto_export=False,
            broker="Deriv-Demo",
        ),
    )

    profiles = tuple(profiles or FULL_MULTI_BOT_PROFILES)
    if profiles == tuple(FULL_MULTI_BOT_PROFILES):
        _assert_full_multibot_architecture(profiles)
    if profiles == tuple(SYNTHETIC_SPLIT_PROFILES):
        _assert_synthetic_split_architecture()
        # El dashboard no debe interpretar un estado persistido del antiguo
        # worker agregado como un séptimo worker activo.
        try:
            repo.upsert_worker_runtime_state(
                "SYNTHETICS",
                BOT_PROFILES["SYNTHETICS"]["magic"],
                source="DEMO",
                status="SUPERSEDED",
                pid=None,
                symbols_total=0,
                symbols_processed=0,
                current_symbol=None,
                last_action="REPLACED_BY_FAMILY_WORKERS",
                last_reason="v60: reemplazado por BOOM/CRASH/VOLATILITY/STEP/JUMP/FLIP",
                details={"version": DAEMONBLACKFX_VERSION, "legacy": True},
            )
        except Exception as exc:
            print(f"[LEGACY RUNTIME CLEANUP ERROR] SYNTHETICS: {exc}", file=sys.stderr)

    if profiles == tuple(FOREX_SPLIT_PROFILES) or all(p in profiles for p in FOREX_SPLIT_PROFILES):
        try:
            repo.upsert_worker_runtime_state(
                "FOREX",
                BOT_PROFILES["FOREX"]["magic"],
                source="DEMO",
                status="SUPERSEDED",
                pid=None,
                symbols_total=0,
                symbols_processed=0,
                current_symbol=None,
                last_action="REPLACED_BY_FOREX_SHARDS",
                last_reason="v69: reemplazado por FOREX_1/FOREX_2/FOREX_3/FOREX_4",
                details={"version": DAEMONBLACKFX_VERSION, "legacy": True},
            )
        except Exception as exc:
            print(f"[LEGACY RUNTIME CLEANUP ERROR] FOREX: {exc}", file=sys.stderr)

    if all(p in profiles for p in VOLATILITY_SHARD_PROFILES):
        try:
            repo.upsert_worker_runtime_state(
                "VOLATILITY",
                BOT_PROFILES["VOLATILITY"]["magic"],
                source="DEMO",
                status="SUPERSEDED",
                pid=None,
                symbols_total=0,
                symbols_processed=0,
                current_symbol=None,
                last_action="REPLACED_BY_VOLATILITY_SHARDS",
                last_reason="v99: reemplazado por VOLATILITY_1/2/3/4",
                details={"version": DAEMONBLACKFX_VERSION, "legacy": True},
            )
        except Exception as exc:
            print(f"[LEGACY RUNTIME CLEANUP ERROR] VOLATILITY: {exc}", file=sys.stderr)

    # v58: los coordinadores multi-bot siempre exponen un único dashboard central.
    # Los workers usan --coordinated-worker y no abren puertos propios.
    dashboard_service = None
    coordinator_dashboard_enabled = True
    if coordinator_dashboard_enabled:
        from dashboard.realtime_dashboard import RealtimeDashboardService

        dashboard_service = RealtimeDashboardService(
            repository=repo,
            host="127.0.0.1",
            port=int(args.dashboard_port),
        )
        try:
            catalog = _build_multi_bot_dashboard_catalog(profiles)
        except Exception as exc:
            catalog = {}
            repo.save_audit_event(
                "DASHBOARD_CATALOG_ERROR",
                source="DEMO",
                action="MULTI_BOT_CATALOG_FAILED",
                reason=str(exc),
            )

        # v82: evita workers sintéticos RUNNING con ciclos permanentes 0/0.
        _recover_empty_synthetic_selection(repo, catalog, profiles)

        # v56: el dashboard recupera SYNTHETICS / FOREX / ORB por separado.
        dashboard_service.set_instrument_catalog(catalog, selected_symbols=None)
        dashboard_url = dashboard_service.start(live=True)
        dashboard_service.update_status("COORDINADOR MULTI-BOT ACTIVO")
        print(f"Dashboard central: {dashboard_url}")
        print(f"Instrumentos: {dashboard_service.instruments_url}")
        print(f"Cuenta activa: {dashboard_service.account_url}")

    workers = {}
    log_handles = {}
    worker_started_at = {}
    worker_progress_fingerprints = {}
    worker_last_progress_at = {}
    worker_stall_warning_at = {}
    disabled_profiles = set()
    blocked_profiles = set()
    worker_lock = threading.RLock()
    shared_db_path = str(Path(repo.db_path).resolve())

    def start_worker(profile):
        """Lanza (o revive) el subproceso worker de un perfil.

        Closure del daemon multibot: comparte `workers`, `worker_lock` y
        `disabled_profiles`. Es idempotente: si el proceso sigue vivo no crea
        otro, y respeta los perfiles deshabilitados desde el dashboard.

        Los perfiles Forex y GOLD reciben un intervalo mas corto porque sus
        ventanas de entrada son mas breves.

        Returns:
            bool: `True` si el worker quedo en ejecucion.
        """
        with worker_lock:
            if profile in disabled_profiles or profile in blocked_profiles:
                return False
            existing = workers.get(profile)
            if existing is not None and existing.poll() is None:
                return True
        spec = BOT_PROFILES[profile]
        worker_interval = (
            min(int(args.interval), 10)
            if str(profile).startswith("FOREX_") or str(profile) == "GOLD"
            else int(args.interval)
        )
        cmd = [
            sys.executable, "-m", "app.main",
            "--mode", spec["mode"],
            "--interval", str(worker_interval),
            "--position-monitor-interval", str(args.position_monitor_interval),
            "--risk-percent", str(args.risk_percent),
            "--min-rr", str(args.min_rr),
            "--coordinated-worker",
        ]
        selected_market_data_mode = (
            getattr(args, "market_data_mode", None)
            or os.getenv("DAEMON_MARKET_DATA_MODE", "shadow")
        )
        cmd.extend(["--market-data-mode", str(selected_market_data_mode)])
        if args.execute:
            cmd.append("--execute")
        if args.verbose:
            cmd.append("--verbose")
        if args.debug:
            cmd.append("--debug")

        log_path = logs_dir / f"{profile.lower()}.log"
        handle = open(log_path, "a", encoding="utf-8", buffering=1)
        worker_env = os.environ.copy()
        # v88: todos los procesos reciben la misma ruta resuelta. Así no pueden
        # crear DB distintas por cwd, usuario o una variable heredada ambigua.
        worker_env["DAEMONBLACKFX_DB_PATH"] = shared_db_path
        proc = subprocess.Popen(
            cmd,
            cwd=PROJECT_ROOT,
            stdout=handle,
            stderr=subprocess.STDOUT,
            env=worker_env,
        )
        with worker_lock:
            workers[profile] = proc
            log_handles[profile] = handle
            worker_started_at[profile] = time.monotonic()
            worker_progress_fingerprints.pop(profile, None)
            worker_last_progress_at[profile] = time.monotonic()
        repo.save_audit_event(
            "BOT_WORKER_STARTED",
            source="DEMO",
            action="WORKER_STARTED",
            reason=profile,
            payload={
                "profile": profile, "pid": proc.pid, "magic": spec["magic"],
                "command": cmd, "shared_db_path": shared_db_path,
            },
        )
        try:
            repo.upsert_worker_runtime_state(
                profile,
                spec["magic"],
                source="DEMO",
                status="STARTING",
                pid=proc.pid,
                cycle_number=0,
                symbols_total=0,
                symbols_processed=0,
                last_action="WORKER_STARTED",
                last_reason=profile,
                details={
                    "command": cmd, "log_path": str(log_path),
                    "version": DAEMONBLACKFX_VERSION,
                    "shared_db_path": shared_db_path,
                    "persistence": {
                        "entry": "trade_visual_audits",
                        "timeline": "trade_audit_snapshots",
                        "runtime": "worker_runtime_states",
                    },
                },
            )
        except Exception as exc:
            print(f"[RUNTIME DB ERROR] {profile}: {exc}", file=sys.stderr)
            try:
                repo.save_audit_event(
                    "WORKER_RUNTIME_PERSIST_ERROR",
                    source="DEMO",
                    action="STARTUP_RUNTIME_FAILED",
                    reason=str(exc),
                    payload={"profile": profile, "pid": proc.pid, "magic": spec["magic"]},
                )
            except Exception:
                pass
        print(f"{profile:<10} PID={proc.pid} MAGIC={spec['magic']} LOG={log_path}")
        return True

    def set_worker_enabled(profile, enabled):
        """Activa o detiene un worker desde el dashboard.

        Salvaguarda clave: NO permite detener un perfil con posiciones
        abiertas; matar su proceso dejaria riesgo vivo sin nadie gestionandolo.

        Returns:
            dict con `ok` y, si falla, `error` explicando el motivo.
        """
        if profile not in profiles:
            return {"ok": False, "error": f"Worker no administrado por este coordinador: {profile}"}
        with worker_lock:
            if enabled:
                disabled_profiles.discard(profile)
                blocked_profiles.discard(profile)
                started = start_worker(profile)
                action = "WORKER_REACTIVATED" if started else "WORKER_ALREADY_RUNNING"
                reason = "Reactivado desde el dashboard"
            else:
                open_positions = []
                for trade in repo.open_trades(source="DEMO") or []:
                    details = trade.get("details") if isinstance(trade, dict) else {}
                    metadata = details.get("metadata") if isinstance(details, dict) else {}
                    if str(metadata.get("bot_profile") or "").upper() == profile:
                        open_positions.append(trade)
                if open_positions:
                    return {
                        "ok": False,
                        "error": (
                            f"{profile} tiene {len(open_positions)} posición(es) abierta(s). "
                            "Ciérralas antes de detener su gestión."
                        ),
                    }
                disabled_profiles.add(profile)
                blocked_profiles.discard(profile)
                proc = workers.pop(profile, None)
                handle = log_handles.pop(profile, None)
                action = "STRATEGY_DISABLED_FROM_DASHBOARD"
                reason = "Desactivado manualmente desde el dashboard"

        if not enabled and proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)
        if not enabled and handle is not None:
            handle.close()

        repo.upsert_worker_runtime_state(
            profile,
            BOT_PROFILES[profile]["magic"],
            source="DEMO",
            status="RUNNING" if enabled else "DISABLED",
            pid=(workers.get(profile).pid if enabled and workers.get(profile) is not None else None),
            last_action=action,
            last_reason=reason,
            details={"dashboard_controlled": True, "enabled": bool(enabled)},
        )
        repo.save_audit_event(
            "BOT_WORKER_CONTROL_CHANGED",
            source="DEMO",
            action=action,
            reason=profile,
            payload={"profile": profile, "enabled": bool(enabled)},
        )
        return {"ok": True, "profile": profile, "enabled": bool(enabled), "action": action}

    if dashboard_service is not None:
        dashboard_service.set_worker_controller(set_worker_enabled)

    startup_stagger = max(
        0.0,
        float(os.getenv("DAEMON_WORKER_START_STAGGER_SECONDS", "1.0")),
    )
    for profile in profiles:
        start_worker(profile)
        if startup_stagger:
            time.sleep(startup_stagger)

    print(f"\nDAEMONBLACKFX VERSION: {DAEMONBLACKFX_VERSION}")
    print("COORDINADOR MULTI-BOT ACTIVO")
    print("DB compartida: SQLAlchemy/SQLite WAL")
    print(f"DB persistente única: {shared_db_path}")
    print("XLSX: escritor único desde el coordinador")
    print(f"Workers: {', '.join(profiles)}")
    if profiles == tuple(SYNTHETIC_SPLIT_PROFILES):
        print("ARQUITECTURA SINTETICOS: 6 PROCESOS INDEPENDIENTES · 1 FAMILIA POR PID")
        print("PID por familia: " + " | ".join(
            f"{profile}={workers[profile].pid}" for profile in SYNTHETIC_SPLIT_PROFILES
        ))
    print("Ctrl+C detiene coordinador y todos los workers.\n")

    last_export = 0.0
    last_worker_console = 0.0
    last_audit_maintenance = time.monotonic()
    try:
        while True:
            now = time.monotonic()
            if now - last_export >= max(5, int(args.report_interval)):
                try:
                    result = reporting.export_now()
                    print(
                        f"[REPORT] trades={result.get('total_trades')} "
                        f"open={result.get('open_positions')} -> {result.get('path')}"
                    )
                except Exception as exc:
                    repo.save_audit_event(
                        "REPORT_EXPORT_ERROR",
                        source="DEMO",
                        action="MULTI_BOT_REPORT_FAILED",
                        reason=str(exc),
                    )
                last_export = now

            if now - last_audit_maintenance >= max(
                300,
                int(getattr(args, "audit_maintenance_interval", 3600)),
            ):
                try:
                    maintenance = repo.maintain_operational_audits(
                        retention_days=getattr(args, "audit_retention_days", 14),
                        max_rows=getattr(args, "audit_retention_max_rows", 250_000),
                        checkpoint_mode="PASSIVE",
                    )
                    deleted = maintenance["retention"]["deleted_total"]
                    if deleted:
                        print(f"[AUDIT RETENTION] filas operativas eliminadas={deleted}")
                except Exception as exc:
                    print(f"[AUDIT RETENTION WARNING] {exc}", file=sys.stderr)
                last_audit_maintenance = now

            if now - last_worker_console >= 10:
                try:
                    runtime_rows = {
                        row.get("bot_profile"): row
                        for row in repo.worker_runtime_states(source="DEMO")
                    }
                    print("[WORKERS] " + " | ".join(
                        (
                            f"{profile}:"
                            f"{runtime_rows.get(profile, {}).get('status', 'SIN_DB')} "
                            f"C{runtime_rows.get(profile, {}).get('cycle_number', 0)} "
                            f"{runtime_rows.get(profile, {}).get('symbols_processed', 0)}/"
                            f"{runtime_rows.get(profile, {}).get('symbols_total', 0)} "
                            f"{runtime_rows.get(profile, {}).get('current_symbol') or 'espera'}"
                        )
                        for profile in profiles
                    ))
                except Exception as exc:
                    print(f"[WORKERS DB ERROR] {exc}", file=sys.stderr)
                last_worker_console = now

            with worker_lock:
                active_workers = list(workers.items())
            for profile, proc in active_workers:
                code = proc.poll()
                if code is None:
                    try:
                        existing = {
                            row.get("bot_profile"): row
                            for row in repo.worker_runtime_states(source="DEMO")
                        }.get(profile, {})

                        # El progreso se mide con telemetría del propio worker,
                        # no con mtime del log: stdout se almacena en bloques en
                        # Windows y puede permanecer sin cambios varios minutos.
                        fingerprint = (
                            existing.get("cycle_number"),
                            existing.get("status"),
                            existing.get("symbols_processed"),
                            existing.get("symbols_total"),
                            existing.get("current_symbol"),
                            existing.get("last_action"),
                            existing.get("last_reason"),
                        )
                        if worker_progress_fingerprints.get(profile) != fingerprint:
                            worker_progress_fingerprints[profile] = fingerprint
                            worker_last_progress_at[profile] = now

                        progress_age = now - worker_last_progress_at.get(
                            profile, worker_started_at.get(profile, now)
                        )
                        stall_timeout = max(
                            60.0,
                            float(os.getenv(
                                "DAEMON_WORKER_STALL_TIMEOUT_SECONDS", "300"
                            )),
                        )
                        if progress_age >= stall_timeout:
                            open_positions = []
                            for trade in repo.open_trades(source="DEMO") or []:
                                details = trade.get("details") if isinstance(trade, dict) else {}
                                metadata = details.get("metadata") if isinstance(details, dict) else {}
                                if str(metadata.get("bot_profile") or "").upper() == profile:
                                    open_positions.append(trade)
                            last_warning = worker_stall_warning_at.get(profile, 0.0)
                            if now - last_warning >= 60.0:
                                worker_stall_warning_at[profile] = now
                                reason = (
                                    f"Sin avance de telemetría durante {progress_age:.0f}s; "
                                    f"posiciones_abiertas={len(open_positions)}"
                                )
                                print(f"[WORKER STALL] {profile}: {reason}", file=sys.stderr)
                                try:
                                    repo.save_audit_event(
                                        "BOT_WORKER_STALLED",
                                        source="DEMO",
                                        action=(
                                            "STALL_RESTART_REQUESTED"
                                            if not open_positions
                                            else "STALL_RESTART_BLOCKED_OPEN_POSITIONS"
                                        ),
                                        reason=profile,
                                        payload={
                                            "profile": profile,
                                            "pid": proc.pid,
                                            "progress_age_seconds": progress_age,
                                            "open_positions": len(open_positions),
                                        },
                                    )
                                except Exception:
                                    pass
                            if not open_positions:
                                proc.terminate()
                                continue

                        repo.upsert_worker_runtime_state(
                            profile,
                            BOT_PROFILES[profile]["magic"],
                            source="DEMO",
                            status=(
                                existing.get("status")
                                if existing.get("status") in {
                                    "DEGRADED_NO_SYMBOLS",
                                    "WAITING_NEW_M5_BAR",
                                    "WAITING_NEW_M1_BAR",
                                    "WAITING_FOREX_DATA",
                                    "OUTSIDE_SESSION",
                                    "SESSION_WARMUP",
                                }
                                else "RUNNING"
                            ),
                            pid=proc.pid,
                            cycle_number=existing.get("cycle_number"),
                            symbols_total=existing.get("symbols_total"),
                            symbols_processed=existing.get("symbols_processed"),
                            current_symbol=existing.get("current_symbol"),
                            last_action=existing.get("last_action") or "HEARTBEAT",
                            last_reason=existing.get("last_reason") or "Proceso activo",
                            details=existing.get("details") or {"version": DAEMONBLACKFX_VERSION},
                        )
                    except Exception as exc:
                        print(f"[RUNTIME HEARTBEAT ERROR] {profile}: {exc}", file=sys.stderr)
                    continue
                if profile in disabled_profiles:
                    continue
                worker_stall_warning_at.pop(profile, None)
                worker_started_at.pop(profile, None)
                worker_progress_fingerprints.pop(profile, None)
                worker_last_progress_at.pop(profile, None)
                if code == 2:
                    # Exit 2 significa que una salvaguarda de arranque (cuenta
                    # DEMO o datos de mercado) bloqueo al worker. Reiniciarlo
                    # cada cinco segundos no puede corregir la configuracion y
                    # oculta el diagnostico bajo un estado STARTING perpetuo.
                    with worker_lock:
                        blocked_profiles.add(profile)
                        workers.pop(profile, None)
                        handle = log_handles.pop(profile, None)
                    try:
                        if handle is not None:
                            handle.close()
                    except Exception:
                        pass
                    repo.save_audit_event(
                        "BOT_WORKER_PREFLIGHT_BLOCKED",
                        source="DEMO",
                        action="PREFLIGHT_BLOCKED",
                        reason=profile,
                        payload={"profile": profile, "exit_code": code},
                    )
                    try:
                        repo.upsert_worker_runtime_state(
                            profile,
                            BOT_PROFILES[profile]["magic"],
                            source="DEMO",
                            status="BLOCKED_PREFLIGHT",
                            pid=None,
                            last_action="PREFLIGHT_BLOCKED",
                            last_reason=(
                                "Preflight rechazado; revise el log del worker y "
                                "reactívelo después de corregir la causa"
                            ),
                            details={"exit_code": code, "restart_suppressed": True},
                        )
                    except Exception:
                        pass
                    print(
                        f"[BLOCKED] {profile} no superó el preflight (código 2). "
                        "No se reiniciará automáticamente; revise su log."
                    )
                    continue
                repo.save_audit_event(
                    "BOT_WORKER_STOPPED",
                    source="DEMO",
                    action="WORKER_EXITED",
                    reason=profile,
                    payload={"profile": profile, "exit_code": code},
                )
                try:
                    repo.upsert_worker_runtime_state(
                        profile,
                        BOT_PROFILES[profile]["magic"],
                        source="DEMO",
                        status="STOPPED",
                        last_action="WORKER_EXITED",
                        last_reason=f"exit_code={code}",
                        details={"exit_code": code},
                    )
                except Exception:
                    pass
                print(f"[WARN] {profile} terminó con código {code}. Reinicio en 5s.")
                try:
                    log_handles[profile].close()
                except Exception:
                    pass
                time.sleep(5)
                start_worker(profile)

            time.sleep(1)
    except KeyboardInterrupt:
        print("\nDeteniendo arquitectura multi-bot...")
    finally:
        for profile, proc in workers.items():
            if proc.poll() is None:
                proc.terminate()
            try:
                repo.upsert_worker_runtime_state(
                    profile,
                    BOT_PROFILES[profile]["magic"],
                    source="DEMO",
                    status="STOPPED",
                    last_action="COORDINATOR_SHUTDOWN",
                    last_reason="Detenido por coordinador",
                )
            except Exception:
                pass
        deadline = time.monotonic() + 10
        for proc in workers.values():
            remaining = max(0.1, deadline - time.monotonic())
            try:
                proc.wait(timeout=remaining)
            except Exception:
                proc.kill()
        for handle in log_handles.values():
            try:
                handle.close()
            except Exception:
                pass
        try:
            reporting.export_now()
        except Exception:
            pass
        if dashboard_service is not None:
            try:
                dashboard_service.mark_offline(
                    "COORDINADOR MULTI-BOT DETENIDO · ESTADO PERSISTIDO"
                )
                dashboard_service.stop()
            except Exception:
                pass
        print("Workers detenidos.")


def run_report_daemon(report_interval: int = 30):
    """Único escritor continuo del XLSX cuando los bots se ejecutan por separado."""
    from reporting.trade_reporting_service import TradeReportingConfig, TradeReportingService

    repo = TradingRepository()
    reporting = TradeReportingService(
        repository=repo,
        config=TradeReportingConfig(
            source="DEMO",
            output_path=PROJECT_ROOT / "storage" / "exports" / "deriv_demo_trading_report.xlsx",
            auto_export=False,
            broker="Deriv-Demo",
        ),
    )

    interval = max(5, int(report_interval))
    print("REPORTER DB -> XLSX ACTIVO")
    print(f"Intervalo: {interval}s")
    print(f"Archivo: {reporting.exporter.output_path}")
    try:
        while True:
            try:
                result = reporting.export_now()
                print(
                    f"[REPORT] trades={result.get('total_trades')} "
                    f"open={result.get('open_positions')}"
                )
            except Exception as exc:
                repo.save_audit_event(
                    "REPORT_EXPORT_ERROR",
                    source="DEMO",
                    action="REPORT_DAEMON_FAILED",
                    reason=str(exc),
                )
                print(f"[REPORT ERROR] {exc}")
            time.sleep(interval)
    except KeyboardInterrupt:
        print("Reporter detenido por el usuario.")


def run_dashboard_only(dashboard_port: int = 8765):
    """
    Levanta únicamente la interfaz web usando SQLAlchemy + último snapshot
    persistido. No abre conexión con MetaTrader5 ni ejecuta operaciones.
    """
    from dashboard.realtime_dashboard import RealtimeDashboardService

    repo = TradingRepository()
    dashboard_service = RealtimeDashboardService(
        repository=repo,
        host="127.0.0.1",
        port=dashboard_port,
    )

    try:
        dashboard_url = dashboard_service.start(live=False)
        print("=== BLACKDAEMONFX · DASHBOARD OFFLINE ===")
        print(f"Dashboard: {dashboard_url}")
        print(f"Cuenta activa: {dashboard_service.account_url}")
        print(f"Instrumentos: {dashboard_service.instruments_url}")
        print("MT5 NO está conectado. Las posiciones OPEN provienen de SQLAlchemy.")
        print("Los precios, salud y gráficos son el último estado persistido y pueden estar desactualizados.")
        print("Presiona Ctrl+C para cerrar sólo la interfaz.")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Dashboard offline detenido por el usuario.")
    finally:
        dashboard_service.mark_offline("DASHBOARD OFFLINE DETENIDO · ESTADO PERSISTIDO")
        dashboard_service.stop()


def run_reset_database(confirm: bool, force_open_trades: bool = False):
    """Modo `reset-db`: vacia la base operativa tras respaldarla.

    Triple proteccion: exige `--confirm-reset-database`, crea siempre un backup
    consistente previo y se niega a borrar si hay operaciones abiertas salvo
    que se fuerce. El historial permanente (`trade_journal`) se conserva.

    Args:
        confirm: confirmacion explicita del usuario.
        force_open_trades: permite el borrado con posiciones abiertas.

    Returns:
        dict con los recuentos eliminados y la ruta del respaldo.

    Raises:
        SystemExit: si no se confirmo la operacion.
    """
    if not confirm:
        raise SystemExit(
            "BLOQUEADO: reset-db requiere --confirm-reset-database. "
            "Detén el daemon antes de limpiar la base."
        )

    from database.database import DEFAULT_DB_PATH

    db_path = Path(DEFAULT_DB_PATH)
    backup_path = None
    repo = TradingRepository(db_path=db_path)
    if db_path.exists():
        backup_dir = PROJECT_ROOT / "database" / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f"trading_bot_before_reset_{stamp}.sqlite3"
        repo.create_consistent_backup(backup_path)

    result = repo.reset_database(allow_open_trades=force_open_trades)

    print("BASE SQLALCHEMY LIMPIADA CORRECTAMENTE")
    print(f"Trades eliminados: {result['trades']}")
    print(f"Señales eliminadas: {result['signals']}")
    print(f"Snapshots de cuenta eliminados: {result['account_snapshots']}")
    print(f"Historial permanente conservado: {result.get('trade_journal_preserved', 0)} trade(s)")
    if backup_path is not None:
        print(f"Respaldo previo: {backup_path}")
    return {**result, "backup_path": str(backup_path) if backup_path else None}


def run_database_maintenance(
    *,
    confirm: bool,
    vacuum: bool,
    retention_days: int,
    max_rows: int,
):
    """Mantenimiento manual seguro para compactar una DB histórica grande."""
    if not confirm:
        raise SystemExit(
            "BLOQUEADO: db-maintenance requiere --confirm-db-maintenance y el daemon detenido."
        )
    guard = _acquire_multibot_instance_guard()
    try:
        repo = TradingRepository()
        backup = repo.create_consistent_backup()
        maintenance = repo.maintain_operational_audits(
            retention_days=retention_days,
            max_rows=max_rows,
            checkpoint_mode="TRUNCATE",
        )
        compact = repo.vacuum_database() if vacuum else None
        result = {
            "backup": backup,
            "maintenance": maintenance,
            "vacuum": compact,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return result
    finally:
        guard.release()



def run_train_meta_labeling(profiles=None, strategy_name: str = "ALL"):
    """Entrena el meta-etiquetado de cada worker con su propio historial.

    Cada perfil aprende sólo de sus operaciones: un modelo nunca mezcla el
    comportamiento de dos workers distintos.
    """
    from database.repository import TradingRepository
    from strategy.ai import MetaLabelingConfig, MetaLabelingEngine

    repository = TradingRepository()

    targets = [str(item).upper() for item in (profiles or [])]
    if not targets:
        targets = [
            "SYNTHETICS", "BOOM", "CRASH", "VOLATILITY",
            "STEP", "JUMP", "FLIP", "GOLD", "FOREX",
        ]

    trades = repository.trade_history_dataframe()
    reports = {}
    for worker in targets:
        engine = MetaLabelingEngine(MetaLabelingConfig(), worker=worker)
        reports[worker] = engine.train(trades, strategy_name=strategy_name)

    print(json.dumps(reports, ensure_ascii=False, indent=2, default=str))
    return reports


def run_reset_account_stats(confirm: bool = False):
    """Reinicia la ventana estadística de Cuenta activa sin borrar el historial físico."""
    from database.database import DEFAULT_DB_PATH

    if not confirm:
        print("Se reiniciarán las estadísticas visibles de Cuenta activa.")
        print("Se conservarán las posiciones ABIERTAS, snapshots y el historial físico en SQLAlchemy.")
        print("Win Rate, cerrados, PnL, TP1/TP2, SL, BE y emergencias comenzarán desde cero.")
        try:
            answer = input("Escriba RESET para continuar: ").strip()
        except EOFError:
            raise SystemExit(
                "BLOQUEADO: no fue posible leer confirmación interactiva. "
                "Use --confirm-reset-account-stats para confirmar explícitamente."
            )
        if answer != "RESET":
            raise SystemExit("RESET CANCELADO: no se escribió RESET.")

    repo = TradingRepository(db_path=Path(DEFAULT_DB_PATH))
    result = repo.reset_account_statistics(source="DEMO", reason="CLI_MANUAL_RESET")

    print("ESTADÍSTICAS DE CUENTA ACTIVA REINICIADAS")
    print(f"Fecha de corte UTC: {result['reset_time']}")
    print(f"Posiciones abiertas conservadas: {result['open_positions_preserved']}")
    print(f"Cierres anteriores ocultos de la nueva ventana: {result['closed_rows_hidden_from_new_window']}")
    print(f"Filas históricas preservadas físicamente: {result['historical_rows_preserved']}")
    print("El historial no fue borrado; sólo se inició una nueva ventana estadística.")
    return result

def run_market_data_preflight(args, symbols=None):
    """Valida Deriv Charts contra los símbolos ejecutables de MT5 sin órdenes."""
    from brokers.mt5_connector import MT5Connector
    from brokers.mt5_data import MT5DataProvider
    from marketdata.factory import ExternalMarketDataSettings, build_market_data_provider

    connector = MT5Connector()
    metadata = MT5DataProvider(connector)
    settings = ExternalMarketDataSettings.from_environment("external")
    provider = build_market_data_provider(metadata, settings=settings)
    maximum_relative_drift = float(
        os.getenv("DAEMON_PREFLIGHT_MAX_RELATIVE_PRICE_DRIFT", "0.05")
    )
    if symbols is None:
        # Mantener el valor solicitado sin resolver permite que el error de un
        # simbolo no publicado por Deriv se informe dentro del resultado del
        # preflight, sin terminar la CLI con un traceback.
        if getattr(args, "symbol", None):
            symbols = [str(args.symbol)]
        elif getattr(args, "categories", None):
            symbols = _resolve_live_symbols(args)
        else:
            catalog = _build_multi_bot_dashboard_catalog(FULL_MULTI_BOT_PROFILES)
            symbols = sorted(
                {str(item) for values in catalog.values() for item in values if item},
                key=str.casefold,
            )

    def transient_failure(message):
        value = str(message or "").casefold()
        return any(marker in value for marker in (
            "rate limit",
            "too many request",
            "no devolvió ticks",
            "no closed",
            "websocket no respondió",
            "websocket no respondio",
            "timed out",
            "timeout",
            "market closed",
        ))

    results = []
    try:
        provider.connect()
        for requested in symbols:
            symbol = str(requested)
            try:
                symbol = provider.ensure_symbol(requested)
                timeframes = {}
                # M5 valida resolución, histórico, vela cerrada y normalización.
                # Pedir cuatro timeframes aquí quintuplicaba el arranque; los
                # demás se validan naturalmente en el primer ciclo del motor.
                for timeframe, count in (("M5", 40),):
                    frame = provider.get_candles(symbol, timeframe=timeframe, count=count)
                    closed = frame[frame["complete"].astype(bool)]
                    if closed.empty:
                        raise RuntimeError(f"DERIV_NO_CLOSED_{timeframe}_CANDLE")
                    timeframes[timeframe] = {
                        "rows": len(frame),
                        "latest_closed": closed.iloc[-1]["time"].isoformat(),
                    }
                deriv_tick = provider.get_current_tick(symbol)
                mt5_tick = metadata.get_current_tick(symbol)
                deriv_mid = (float(deriv_tick["bid"]) + float(deriv_tick["ask"])) / 2
                mt5_mid = (float(mt5_tick["bid"]) + float(mt5_tick["ask"])) / 2
                relative_drift = abs(deriv_mid - mt5_mid) / max(abs(mt5_mid), 1e-12)
                if relative_drift > maximum_relative_drift:
                    raise RuntimeError(
                        f"DERIV_MT5_PRICE_MISMATCH relative_drift={relative_drift:.6f} "
                        f"limit={maximum_relative_drift:.6f}"
                    )
                results.append({
                    "symbol": symbol,
                    "ok": True,
                    "native_symbol": deriv_tick.get("native_symbol"),
                    "source": deriv_tick.get("source"),
                    "relative_price_drift": relative_drift,
                    "timeframes": timeframes,
                })
            except Exception as exc:
                message = str(exc)
                results.append({
                    "symbol": symbol,
                    "ok": False,
                    "deferred": transient_failure(message),
                    "error": message,
                })
    finally:
        provider.disconnect()

    successful = [row for row in results if row["ok"]]
    deferred = [row for row in results if not row["ok"] and row.get("deferred")]
    failed = [row for row in results if not row["ok"] and not row.get("deferred")]
    print("=" * 72)
    print("DAEMONBLACKFX · PREFLIGHT DERIV CHARTS → MT5")
    print("=" * 72)
    for row in results:
        if row["ok"]:
            print(
                f"[OK] {row['symbol']} -> {row['native_symbol']} | "
                f"drift={row['relative_price_drift']:.6f} | M5/TICK=OK"
            )
        elif row.get("deferred"):
            print(f"[DEFERRED] {row['symbol']} -> {row['error']}")
        else:
            print(f"[ERROR] {row['symbol']} -> {row['error']}")
    print(
        f"Resumen: OK={len(successful)} DEFERRED={len(deferred)} "
        f"ERROR={len(failed)}"
    )
    runnable = successful + deferred
    return {
        # Un instrumento exclusivo de MT5 no debe detener una familia entera.
        # Sólo los símbolos verificados pasan al worker de análisis/ejecución.
        "ready": bool(runnable),
        "all_supported": not failed,
        "symbols": [row["symbol"] for row in runnable],
        "results": results,
        "deferred": deferred,
        "failed": failed,
    }


def main():
    """CLI del proyecto: interpreta los argumentos y despacha el modo elegido.

    Valida primero los timeframes, construye el parser con todos los modos
    (collect, daemon, report, analyze, backtest, demo, live-paper,
    demo-preflight, live-demo-smoke, multi-bot-daemon, reset-db, ...) y delega
    en la funcion `run_*` correspondiente.

    Es el unico punto de entrada del proyecto: todo proceso arranca aqui.
    """
    _validate_timeframes()

    parser = argparse.ArgumentParser(
        description="SMC Synthetic Bot"
    )

    parser.add_argument(
        "--mode",
        choices=[
            "collect",
            "daemon",
            "report",
            "analyze",
            "backtest",
            "demo",
            "demo-daemon",
            "live-paper",
            "live-paper-daemon",
            "demo-preflight",
            "live-demo-smoke",
            "reset-db",
            "db-maintenance",
            "reset-account-stats",
            "dashboard-only",
            "synthetic-daemon",
            "boom-daemon",
            "crash-daemon",
            "volatility-daemon",
            "volatility-1-daemon",
            "volatility-2-daemon",
            "volatility-3-daemon",
            "volatility-4-daemon",
            "step-daemon",
            "jump-daemon",
            "flip-daemon",
            "forex-daemon",
            "forex-split-daemon",
            "forex-1-daemon",
            "forex-2-daemon",
            "forex-3-daemon",
            "forex-4-daemon",
            "gold-session-daemon",
            "orb-daemon",
            "idx-open-daemon",
            "synthetics-split-daemon",
            "multi-bot-daemon",
            "unified-multibot-daemon",
            "report-daemon",
            "train-meta-labeling",
            "market-data-preflight",
        ],
        default="collect",
    )

    parser.add_argument(
        "--interval",
        type=int,
        default=60,
        help="Segundos entre ciclos en modo daemon",
    )

    parser.add_argument(
        "--market-data-mode",
        choices=["external", "shadow", "mt5"],
        default=None,
        help=(
            "Fuente de análisis: external=Deriv, shadow=Deriv comparado con MT5, "
            "mt5=legado. v113.1 usa shadow por defecto."
        ),
    )

    parser.add_argument(
        "--position-monitor-interval",
        type=int,
        default=2,
        help=(
            "Segundos entre revisiones de posiciones abiertas y Break Even "
            "en demo-daemon. Por defecto: 2."
        ),
    )

    parser.add_argument(
        "--symbol",
        default=None,
        help=(
            "Símbolo exacto o nombre resoluble por MT5. "
            "Si se omite en modos live/demo/collect, "
            "se descubren sintéticos dinámicamente."
        ),
    )

    parser.add_argument(
        "--categories",
        default=None,
        help=(
            "Categorías separadas por coma para descubrimiento dinámico. "
            "Ejemplo: boom,crash,volatility"
        ),
    )

    parser.add_argument(
        "--timeframe",
        default=TIMEFRAMES["entry"],
    )

    parser.add_argument(
        "--file",
        default=(
            "data/historical/"
            "Volatility_90_Index_M5_2026_08.csv"
        ),
    )

    parser.add_argument(
        "--confirm-live-demo",
        action="store_true",
        help="Confirmación explícita obligatoria para abrir una orden real en DEMO.",
    )

    parser.add_argument(
        "--direction",
        choices=["BUY", "SELL"],
        default="BUY",
        help="Dirección usada únicamente por live-demo-smoke.",
    )

    parser.add_argument(
        "--keep-open",
        action="store_true",
        help="En live-demo-smoke no cierra automáticamente la posición.",
    )

    parser.add_argument(
        "--execute",
        action="store_true",
        help=(
            "Permite enviar órdenes únicamente "
            "en modo DEMO."
        ),
    )

    parser.add_argument(
        "--paper-volume",
        type=float,
        default=1.0,
        help="Volumen virtual para live-paper",
    )

    parser.add_argument(
        "--live-volume",
        type=float,
        default=0.0,
        help=(
            "Volumen para live-demo-smoke. 0 = usar automáticamente "
            "el volumen mínimo permitido por el símbolo."
        ),
    )

    parser.add_argument(
        "--risk-percent",
        type=float,
        default=1.0,
    )

    parser.add_argument(
        "--min-rr",
        type=float,
        default=1.5,
    )

    parser.add_argument(
        "--chart-pattern-conflict-min-margin",
        type=float,
        default=0.15,
        help=(
            "Margen minimo (0-1) por el que el patron chartista alineado debe "
            "superar al contrario para NO bloquear la entrada. Ej: 0.25 exige "
            "que el alineado sea al menos 25 puntos porcentuales mas fuerte "
            "que el contrario; por debajo de ese margen (o si el contrario es "
            "igual o mas fuerte) se bloquea la entrada."
        ),
    )

    parser.add_argument(
        "--hard-risk-tolerance",
        type=float,
        default=0.035,
        help=(
            "Tolerancia (0-1) sobre el riesgo objetivo antes de considerar "
            "que el fill excedió el tope duro (hard cap). Ej: 0.035 permite "
            "hasta un 3.5%% de exceso tras el fill sin marcarlo como breach. "
            "Súbelo si un símbolo entra seguido en cuarentena por la "
            "granularidad de su lote mínimo (ej. Step Index 500)."
        ),
    )
    parser.add_argument(
        "--recoverable-quarantine-extra-tolerance",
        type=float,
        default=0.015,
        help=(
            "Tolerancia adicional (0-1), sumada a --hard-risk-tolerance, "
            "hasta la cual un breach de riesgo post-fill se clasifica como "
            "RECUPERABLE (cuarentena temporal que expira sola) en vez de "
            "requerir revisión manual. Ej: con hard-risk-tolerance=0.035 y "
            "este valor en 0.015, un exceso de hasta 5%% se auto-recupera."
        ),
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Muestra rechazos y detalles adicionales de cada símbolo.",
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Muestra el diagnóstico técnico completo de cada resultado.",
    )

    parser.add_argument(
        "--dashboard",
        action="store_true",
        help="Activa interfaz web local de calidad de trades en tiempo real.",
    )

    parser.add_argument(
        "--dashboard-port",
        type=int,
        default=8765,
        help="Puerto local para --dashboard. Por defecto: 8765.",
    )

    parser.add_argument(
        "--reset-account-stats",
        action="store_true",
        help=(
            "Reinicia Win Rate y estadísticas persistentes de Cuenta activa "
            "sin borrar posiciones abiertas ni el historial físico."
        ),
    )

    parser.add_argument(
        "--confirm-reset-account-stats",
        action="store_true",
        help=(
            "Confirma reset-account-stats sin solicitar escribir RESET. "
            "Útil para scripts/automatizaciones."
        ),
    )

    parser.add_argument(
        "--confirm-reset-database",
        action="store_true",
        help="Confirmación explícita para vaciar trades, signals y account_snapshots.",
    )

    parser.add_argument(
        "--force-reset-open-trades",
        action="store_true",
        help="Permite reset-db aun si SQLite contiene trades OPEN. Usar sólo con MT5 sin posiciones activas.",
    )

    parser.add_argument(
        "--confirm-db-maintenance",
        action="store_true",
        help="Confirma retención/checkpoint y respaldo consistente con el daemon detenido.",
    )

    parser.add_argument(
        "--vacuum",
        action="store_true",
        help="En db-maintenance compacta físicamente SQLite después de crear respaldo.",
    )

    parser.add_argument(
        "--coordinated-worker",
        action="store_true",
        help=argparse.SUPPRESS,
    )

    parser.add_argument(
        "--report-interval",
        type=int,
        default=300,
        help="Segundos entre reconstrucciones del XLSX en multi-bot-daemon.",
    )

    parser.add_argument(
        "--audit-retention-days",
        type=int,
        default=14,
        help="Días de telemetría operacional a conservar; no afecta trades ni auditorías visuales.",
    )

    parser.add_argument(
        "--audit-retention-max-rows",
        type=int,
        default=250000,
        help="Máximo de eventos operacionales de alta frecuencia conservados.",
    )

    parser.add_argument(
        "--audit-maintenance-interval",
        type=int,
        default=3600,
        help="Segundos entre retención/checkpoint SQLite coordinados.",
    )

    parser.add_argument(
        "--meta-labeling-profiles",
        nargs="*",
        default=None,
        help="Workers a entrenar en modo train-meta-labeling. Por defecto, todos.",
    )

    parser.add_argument(
        "--meta-labeling-strategy",
        default="ALL",
        help="Estrategia a entrenar (SMC, ORB_NEW_YORK o ALL).",
    )

    args = parser.parse_args()

    if args.mode == "market-data-preflight":
        result = run_market_data_preflight(args)
        if not result["ready"]:
            raise SystemExit(2)
        return

    if args.mode == "train-meta-labeling":
        run_train_meta_labeling(
            profiles=args.meta_labeling_profiles,
            strategy_name=args.meta_labeling_strategy,
        )
        return

    if args.reset_account_stats or args.mode == "reset-account-stats":
        run_reset_account_stats(confirm=args.confirm_reset_account_stats)
        return

    if args.mode == "dashboard-only":
        run_dashboard_only(args.dashboard_port)
        return

    if args.mode == "reset-db":
        run_reset_database(args.confirm_reset_database, args.force_reset_open_trades)
        return

    if args.mode == "db-maintenance":
        run_database_maintenance(
            confirm=args.confirm_db_maintenance,
            vacuum=args.vacuum,
            retention_days=args.audit_retention_days,
            max_rows=args.audit_retention_max_rows,
        )
        return

    if args.mode == "report-daemon":
        run_report_daemon(args.report_interval)
        return

    # v60: cualquier entrada de daemon sintético agregado se redirige al
    # coordinador por familias. Evita volver accidentalmente al worker legacy
    # SYNTHETICS (magic 26082026) al usar comandos históricos.
    synthetic_split_modes = {
        "synthetics-split-daemon",
        "synthetic-daemon",
        "demo-daemon",
    }
    if args.mode == "multi-bot-daemon":
        if args.interval < 1 or args.position_monitor_interval < 1:
            raise SystemExit("Los intervalos deben ser >= 1 segundo.")
        # v90: el bloqueo se adquiere antes de crear dashboard, DB writer o
        # workers. Aunque Windows ejecute el comando dos veces casi al mismo
        # tiempo, sólo un coordinador puede continuar.
        instance_guard = _acquire_multibot_instance_guard()
        print(
            "[v77] MULTIBOT HÍBRIDO: workers de cálculo independientes + "
            "un único dashboard central liviano."
        )
        try:
            run_multi_bot_daemon(args, profiles=FULL_MULTI_BOT_PROFILES)
        finally:
            instance_guard.release()
        return

    if args.mode == "unified-multibot-daemon":
        if args.interval < 1 or args.position_monitor_interval < 1:
            raise SystemExit("Los intervalos deben ser >= 1 segundo.")
        print(
            "[EXPERIMENTAL] MultiBot unificado en un solo proceso. "
            "No recomendado para operación normal por latencia acumulativa."
        )
        run_unified_multibot_daemon(args, profiles=FULL_MULTI_BOT_PROFILES)
        return

    if args.mode in synthetic_split_modes:
        if args.interval < 1 or args.position_monitor_interval < 1:
            raise SystemExit("Los intervalos deben ser >= 1 segundo.")
        profiles = SYNTHETIC_SPLIT_PROFILES
        if args.mode in {"synthetic-daemon", "demo-daemon"}:
            print(
                f"[v60] {args.mode} es alias protegido de synthetics-split-daemon: "
                "se iniciarán 6 procesos por familia."
            )
        run_multi_bot_daemon(args, profiles=profiles)
        return

    if args.mode in {"forex-daemon", "forex-split-daemon"}:
        if args.interval < 1 or args.position_monitor_interval < 1:
            raise SystemExit("Los intervalos deben ser >= 1 segundo.")
        print("[v69] FOREX EVENT SCHEDULER: 4 workers independientes + caché H1/M15 + eventos M5.")
        run_multi_bot_daemon(args, profiles=FOREX_SPLIT_PROFILES)
        return

    strategy_worker_modes = {
        "boom-daemon": "BOOM",
        "crash-daemon": "CRASH",
        "volatility-daemon": "VOLATILITY",
        "volatility-1-daemon": "VOLATILITY_1",
        "volatility-2-daemon": "VOLATILITY_2",
        "volatility-3-daemon": "VOLATILITY_3",
        "volatility-4-daemon": "VOLATILITY_4",
        "step-daemon": "STEP",
        "jump-daemon": "JUMP",
        "flip-daemon": "FLIP",
        "forex-1-daemon": "FOREX_1",
        "forex-2-daemon": "FOREX_2",
        "forex-3-daemon": "FOREX_3",
        "forex-4-daemon": "FOREX_4",
        "gold-session-daemon": "GOLD",
        "orb-daemon": "ORB",
        "idx-open-daemon": "IDX_OPEN",
    }
    if args.mode in strategy_worker_modes:
        profile = strategy_worker_modes[args.mode]
        symbols = _resolve_live_symbols_for_profile(args, profile)
        if not symbols:
            print(f"{profile}: sin instrumentos seleccionados; worker queda activo sólo para monitor/auditoría.")
        if args.execute and symbols:
            preflight = run_demo_preflight(symbols)
            if not preflight["ready"]:
                raise SystemExit(2)
            market_preflight = run_market_data_preflight(args, symbols=symbols)
            if not market_preflight["ready"]:
                raise SystemExit(2)
            symbols = market_preflight["symbols"]
            if market_preflight["failed"]:
                print(
                    f"[MARKET DATA DEGRADED] {profile}: "
                    f"{len(market_preflight['failed'])} instrumento(s) excluido(s); "
                    f"{len(symbols)} validado(s) continúan."
                )
        run_demo_bot(
            symbols,
            args.timeframe,
            args.interval,
            once=False,
            execute=args.execute,
            risk_percent=args.risk_percent,
            min_rr=args.min_rr,
            verbose=args.verbose,
            debug=args.debug,
            position_monitor_interval=args.position_monitor_interval,
            dashboard=(args.dashboard and not args.coordinated_worker),
            dashboard_port=args.dashboard_port,
            bot_profile=profile,
            magic=BOT_PROFILES[profile]["magic"],
            auto_export=False,
            chart_pattern_conflict_min_margin=args.chart_pattern_conflict_min_margin,
            hard_risk_tolerance=args.hard_risk_tolerance,
            recoverable_quarantine_extra_tolerance=args.recoverable_quarantine_extra_tolerance,
            market_data_mode=args.market_data_mode,
        )
        return

    live_modes = {
        "live-paper",
        "live-paper-daemon",
        "demo",
        "demo-daemon",
        "demo-preflight",
        "live-demo-smoke",
    }

    if args.mode in live_modes:
        symbols = _resolve_live_symbols(args)

        if args.mode == "demo-preflight":
            result = run_demo_preflight(symbols)
            if not result["ready"]:
                raise SystemExit(2)

        elif args.mode == "live-demo-smoke":
            if not args.confirm_live_demo:
                raise SystemExit(
                    "BLOQUEADO: live-demo-smoke requiere --confirm-live-demo. "
                    "Esta acción abre una orden real en la cuenta DEMO."
                )
            if not args.symbol:
                raise SystemExit("live-demo-smoke requiere --symbol explícito")
            preflight = run_demo_preflight(symbols)
            if not preflight["ready"]:
                raise SystemExit(2)
            run_live_demo_smoke(
                symbol=symbols[0],
                direction=args.direction,
                volume=args.live_volume,
                auto_close=not args.keep_open,
            )

        elif args.mode == "live-paper":
            run_live_paper(
                symbols,
                args.interval,
                once=True,
                volume=args.paper_volume,
                market_data_mode=args.market_data_mode,
            )

        elif args.mode == "live-paper-daemon":
            run_live_paper(
                symbols,
                args.interval,
                once=False,
                volume=args.paper_volume,
                market_data_mode=args.market_data_mode,
            )

        elif args.mode == "demo":
            if args.execute:
                preflight = run_demo_preflight(symbols)
                if not preflight["ready"]:
                    raise SystemExit(2)
                market_preflight = run_market_data_preflight(args, symbols=symbols)
                if not market_preflight["ready"]:
                    raise SystemExit(2)
                symbols = market_preflight["symbols"]
            run_demo_bot(
                symbols,
                args.timeframe,
                args.interval,
                once=True,
                execute=args.execute,
                risk_percent=args.risk_percent,
                min_rr=args.min_rr,
                verbose=args.verbose,
                debug=args.debug,
                position_monitor_interval=args.position_monitor_interval,
                dashboard=args.dashboard,
                dashboard_port=args.dashboard_port,
                chart_pattern_conflict_min_margin=args.chart_pattern_conflict_min_margin,
                hard_risk_tolerance=args.hard_risk_tolerance,
                recoverable_quarantine_extra_tolerance=args.recoverable_quarantine_extra_tolerance,
                market_data_mode=args.market_data_mode,
            )

        else:
            if args.interval < 1:
                raise SystemExit(
                    "demo-daemon requiere --interval mínimo de 1 segundo."
                )
            if args.position_monitor_interval < 1:
                raise SystemExit(
                    "--position-monitor-interval requiere un mínimo de 1 segundo."
                )
            if args.execute:
                preflight = run_demo_preflight(symbols)
                if not preflight["ready"]:
                    raise SystemExit(2)
                market_preflight = run_market_data_preflight(args, symbols=symbols)
                if not market_preflight["ready"]:
                    raise SystemExit(2)
                symbols = market_preflight["symbols"]
            run_demo_bot(
                symbols,
                args.timeframe,
                args.interval,
                once=False,
                execute=args.execute,
                risk_percent=args.risk_percent,
                min_rr=args.min_rr,
                verbose=args.verbose,
                debug=args.debug,
                position_monitor_interval=args.position_monitor_interval,
                dashboard=args.dashboard,
                dashboard_port=args.dashboard_port,
                chart_pattern_conflict_min_margin=args.chart_pattern_conflict_min_margin,
                hard_risk_tolerance=args.hard_risk_tolerance,
                recoverable_quarantine_extra_tolerance=args.recoverable_quarantine_extra_tolerance,
                market_data_mode=args.market_data_mode,
            )

        return

    if args.mode == "collect":
        run_collector(
            once=True,
            symbol=args.symbol,
            categories=args.categories,
            market_data_mode=args.market_data_mode,
        )

    elif args.mode == "daemon":
        if args.interval < 30:
            raise ValueError(
                "El intervalo mínimo es 30 segundos."
            )

        run_collector(
            interval_seconds=args.interval,
            once=False,
            symbol=args.symbol,
            categories=args.categories,
            market_data_mode=args.market_data_mode,
        )

    elif args.mode == "report":
        path = export_trading_report()
        print(f"Reporte generado: {path}")

    elif args.mode == "backtest":
        symbol = _require_symbol_for_offline_mode(
            args.symbol,
            args.mode,
        )

        entries_file = Path(
            "storage/analysis"
        ) / (
            f"{symbol.replace(' ', '_')}_"
            f"{args.timeframe}_confirmations.csv"
        )

        result = run_full_backtest_pipeline(
            historical_file=args.file,
            entries_file=entries_file,
            instrument=symbol,
            timeframe=args.timeframe,
            initial_balance=1000.0,
            risk_percent=1.0,
            compound=True,
            strategy_version="smc-v1-backtest",
        )

        print("\n=== BACKTEST COMPLETO ===")
        print(f"Velas: {result['candles']}")
        print(f"Entradas: {result['entries']}")
        print(f"Operaciones: {result['trades']}")
        print(
            f"Backtest: {result['backtest_file']}"
        )
        print(
            "Money management: "
            f"{result['money_management_file']}"
        )
        print(
            "Nuevas operaciones SQLite: "
            f"{result['persistence']['import']['created']}"
        )
        print(
            f"Reporte Excel: "
            f"{result['persistence']['report']}"
        )

    else:
        symbol = _require_symbol_for_offline_mode(
            args.symbol,
            args.mode,
        )

        analyze_historical(
            symbol,
            args.timeframe,
            args.file,
        )


if __name__ == "__main__":
    main()
